package com.example.data.model

enum class BookingStatus {
    PENDING,
    ASSIGNED,
    IN_PROGRESS,
    COMPLETED,
    CANCELLED;

    val displayName: String
        get() = when (this) {
            PENDING -> "Pending"
            ASSIGNED -> "Assigned"
            IN_PROGRESS -> "In Progress"
            COMPLETED -> "Completed"
            CANCELLED -> "Cancelled"
        }
}

data class Booking(
    val id: String = "",
    val customerId: String = "",
    val customerName: String = "",
    val customerPhone: String = "",
    val customerAddress: String = "",
    val serviceId: String = "",
    val serviceTitle: String = "",
    val serviceCategory: String = "",
    val price: Double = 0.0,
    val extraCharges: Double = 0.0,
    val bookingDate: String = "",
    val bookingTime: String = "",
    val isEmergency: Boolean = false,
    val notes: String = "",
    val status: BookingStatus = BookingStatus.PENDING,
    val technicianId: String? = null,
    val technicianName: String? = null,
    val technicianPhone: String? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val completedAt: Long? = null,
    val rating: Float? = null,
    val reviewComment: String? = null,
    val cancellationReason: String? = null,
    val paymentMethod: String = "UPI (Google Pay / PhonePe)"
) {
    val totalPrice: Double
        get() = price + extraCharges

    val formattedTotal: String
        get() = "₹${totalPrice.toInt()}"
}
