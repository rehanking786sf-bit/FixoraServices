package com.example.data.model

enum class UserRole {
    CUSTOMER,
    TECHNICIAN;

    val displayName: String
        get() = when (this) {
            CUSTOMER -> "Customer"
            TECHNICIAN -> "Technician Partner"
        }
}

data class User(
    val id: String = "",
    val name: String = "",
    val email: String = "",
    val phone: String = "",
    val role: UserRole = UserRole.CUSTOMER,
    val avatarUrl: String? = null,
    val address: String = "",
    val city: String = "Delhi NCR",
    val isOnline: Boolean = true,
    val skills: List<String> = emptyList(),
    val rating: Float = 4.8f,
    val completedJobsCount: Int = 0,
    val isVerified: Boolean = true,
    // Government of India Identification for Technicians
    val governmentIdType: String = "Aadhaar Card",
    val governmentIdNumber: String = "",
    val governmentIdDocName: String = "",
    val verificationStatus: String = "VERIFIED"
)
