package com.example.data.model

data class ServiceItem(
    val id: String = "",
    val title: String = "",
    val category: String = "",
    val description: String = "",
    val price: Double = 0.0,
    val durationMinutes: Int = 60,
    val inclusions: List<String> = emptyList(),
    val warrantyDays: Int = 30,
    val rating: Float = 4.8f,
    val reviewCount: Int = 120,
    val isActive: Boolean = true,
    val iconName: String = "build"
) {
    val formattedPrice: String
        get() = "₹${price.toInt()}"
}
