package com.example.data.model

data class NotificationItem(
    val id: String = "",
    val userId: String = "",
    val title: String = "",
    val message: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false,
    val bookingId: String? = null,
    val type: String = "STATUS_UPDATE" // STATUS_UPDATE, ASSIGNMENT, PROMO, ALERT
)

data class ReviewItem(
    val id: String = "",
    val bookingId: String = "",
    val serviceId: String = "",
    val serviceTitle: String = "",
    val customerName: String = "",
    val technicianName: String = "",
    val rating: Float = 5.0f,
    val comment: String = "",
    val date: String = ""
)

data class ComplaintItem(
    val id: String = "",
    val bookingId: String = "",
    val customerName: String = "",
    val subject: String = "",
    val message: String = "",
    val status: String = "OPEN", // OPEN, RESOLVED
    val date: String = ""
)
