package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import com.example.data.model.Booking
import com.example.data.model.BookingStatus
import com.example.data.model.CityVote
import com.example.data.model.NotificationItem
import com.example.data.model.ReviewItem
import com.example.data.model.ServiceItem
import com.example.data.model.ServiceableCity
import com.example.data.model.User
import com.example.data.model.UserRole
import com.google.firebase.FirebaseApp
import com.google.firebase.FirebaseOptions
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

class FixoraRepository private constructor(private val appContext: Context) {

    private val scope = CoroutineScope(Dispatchers.IO)
    private var firestore: FirebaseFirestore? = null
    private var firebaseAuth: FirebaseAuth? = null
    private val prefs: SharedPreferences = appContext.getSharedPreferences("fixora_session_prefs", Context.MODE_PRIVATE)

    companion object {
        const val SUPER_ADMIN_EMAIL = "rehanking786sf@gmail.com"

        @Volatile
        private var instance: FixoraRepository? = null

        fun getInstance(context: Context): FixoraRepository {
            return instance ?: synchronized(this) {
                instance ?: FixoraRepository(context.applicationContext).also { instance = it }
            }
        }
    }

    // Default Demo Users (Only Customer & Technician)
    val demoCustomer = User(
        id = "cust_in_101",
        name = "Aarav Sharma",
        email = "aarav.sharma@fixora.in",
        phone = "+91 98765 43210",
        role = UserRole.CUSTOMER,
        address = "Tower 4, Flat 702, Godrej Woods, Sector 43, Noida, UP",
        city = "Delhi NCR",
        rating = 4.9f
    )

    val demoTechnician = User(
        id = "tech_in_201",
        name = "Rajesh Kumar Verma",
        email = "rajesh.tech@fixora.in",
        phone = "+91 98234 56789",
        role = UserRole.TECHNICIAN,
        address = "H-14, Street 3, Laxmi Nagar, New Delhi",
        city = "Delhi NCR",
        isOnline = true,
        skills = listOf("Split AC Foam Jet Wash", "Gas Refill R32/R410A", "Inverter PCB Repair"),
        rating = 4.92f,
        completedJobsCount = 284,
        isVerified = true,
        governmentIdType = "Aadhaar Card",
        governmentIdNumber = "XXXX XXXX 7812",
        governmentIdDocName = "aadhaar_rajesh_kumar.pdf",
        verificationStatus = "VERIFIED"
    )

    val demoTechnician2 = User(
        id = "tech_in_202",
        name = "Suresh Kalaburagi",
        email = "suresh.tech@fixora.in",
        phone = "+91 98450 12345",
        role = UserRole.TECHNICIAN,
        address = "Station Road, Jewargi Cross, Gulbarga, Karnataka",
        city = "Gulbarga",
        isOnline = true,
        skills = listOf("Split AC Jet Service", "Kent RO Repair", "Geyser Installation"),
        rating = 4.88f,
        completedJobsCount = 120,
        isVerified = true,
        governmentIdType = "Aadhaar Card",
        governmentIdNumber = "XXXX XXXX 4419",
        governmentIdDocName = "aadhaar_suresh_gulbarga.pdf",
        verificationStatus = "VERIFIED"
    )

    private val _currentUser = MutableStateFlow<User?>(null)
    val currentUser: StateFlow<User?> = _currentUser.asStateFlow()

    private val _selectedCity = MutableStateFlow("Delhi NCR")
    val selectedCity: StateFlow<String> = _selectedCity.asStateFlow()

    private val _serviceableCities = MutableStateFlow<List<ServiceableCity>>(emptyList())
    val serviceableCities: StateFlow<List<ServiceableCity>> = _serviceableCities.asStateFlow()

    private val _cityVotes = MutableStateFlow<List<CityVote>>(emptyList())
    val cityVotes: StateFlow<List<CityVote>> = _cityVotes.asStateFlow()

    private val _services = MutableStateFlow<List<ServiceItem>>(emptyList())
    val services: StateFlow<List<ServiceItem>> = _services.asStateFlow()

    private val _bookings = MutableStateFlow<List<Booking>>(emptyList())
    val bookings: StateFlow<List<Booking>> = _bookings.asStateFlow()

    private val _notifications = MutableStateFlow<List<NotificationItem>>(emptyList())
    val notifications: StateFlow<List<NotificationItem>> = _notifications.asStateFlow()

    private val _users = MutableStateFlow<List<User>>(emptyList())
    val users: StateFlow<List<User>> = _users.asStateFlow()

    private val _reviews = MutableStateFlow<List<ReviewItem>>(emptyList())
    val reviews: StateFlow<List<ReviewItem>> = _reviews.asStateFlow()

    init {
        initializeFirebaseWithUserConfig()
        restorePersistedSession()
        loadAndSyncFirestoreData()
    }

    private fun initializeFirebaseWithUserConfig() {
        try {
            val options = FirebaseOptions.Builder()
                .setApiKey("AIzaSyC5tteMpA4eUgZ6oiDGThSgxzrbQ8bny1w")
                .setApplicationId("1:742133203632:web:6ce3f428f17ac19af67175")
                .setProjectId("fixora-5e807")
                .setStorageBucket("fixora-5e807.firebasestorage.app")
                .setGcmSenderId("742133203632")
                .build()

            if (FirebaseApp.getApps(appContext).isEmpty()) {
                FirebaseApp.initializeApp(appContext, options)
            }
            firestore = FirebaseFirestore.getInstance()
            firebaseAuth = FirebaseAuth.getInstance()
            Log.d("FixoraRepository", "Connected to Firebase project fixora-5e807 successfully")
        } catch (e: Exception) {
            Log.w("FixoraRepository", "Firebase initialization check: ${e.message}")
            try {
                if (FirebaseApp.getApps(appContext).isNotEmpty()) {
                    firestore = FirebaseFirestore.getInstance()
                    firebaseAuth = FirebaseAuth.getInstance()
                }
            } catch (ignored: Exception) {}
        }
    }

    private fun restorePersistedSession() {
        val savedId = prefs.getString("user_id", null)
        val savedEmail = prefs.getString("user_email", null)

        val savedCity = prefs.getString("selected_city", "Delhi NCR") ?: "Delhi NCR"
        _selectedCity.value = savedCity

        if (!savedId.isNullOrBlank() && !savedEmail.isNullOrBlank()) {
            val savedName = prefs.getString("user_name", "User") ?: "User"
            val savedPhone = prefs.getString("user_phone", "+91 98765 43210") ?: "+91 98765 43210"
            val savedAddress = prefs.getString("user_address", "Sector 62, Noida, UP") ?: "Sector 62, Noida, UP"
            val savedCityVal = prefs.getString("user_city", "Delhi NCR") ?: "Delhi NCR"
            val savedRoleStr = prefs.getString("user_role", UserRole.CUSTOMER.name) ?: UserRole.CUSTOMER.name
            val savedRole = try { UserRole.valueOf(savedRoleStr) } catch (e: Exception) { UserRole.CUSTOMER }

            val restored = User(
                id = savedId,
                name = savedName,
                email = savedEmail,
                phone = savedPhone,
                address = savedAddress,
                city = savedCityVal,
                role = if (savedRole == UserRole.TECHNICIAN) UserRole.TECHNICIAN else UserRole.CUSTOMER,
                isOnline = true,
                isVerified = true,
                governmentIdType = prefs.getString("user_govt_id_type", "Aadhaar Card") ?: "Aadhaar Card",
                governmentIdNumber = prefs.getString("user_govt_id_num", "") ?: "",
                governmentIdDocName = prefs.getString("user_govt_id_doc", "") ?: "",
                verificationStatus = prefs.getString("user_govt_id_status", "VERIFIED") ?: "VERIFIED"
            )
            _currentUser.value = restored
        } else {
            // Default Customer for immediate ready usage
            _currentUser.value = demoCustomer
            persistUserSession(demoCustomer)
        }
    }

    private fun persistUserSession(user: User?) {
        val editor = prefs.edit()
        if (user == null) {
            editor.remove("user_id")
            editor.remove("user_email")
            editor.apply()
        } else {
            editor.putString("user_id", user.id)
                .putString("user_email", user.email)
                .putString("user_name", user.name)
                .putString("user_phone", user.phone)
                .putString("user_address", user.address)
                .putString("user_city", user.city)
                .putString("user_role", user.role.name)
                .putString("user_govt_id_type", user.governmentIdType)
                .putString("user_govt_id_num", user.governmentIdNumber)
                .putString("user_govt_id_doc", user.governmentIdDocName)
                .putString("user_govt_id_status", user.verificationStatus)
                .apply()
        }
    }

    private fun loadAndSyncFirestoreData() {
        // Default Serviceable Cities including Gulbarga as requested
        val defaultCities = listOf(
            ServiceableCity(id = "city_1", name = "Delhi NCR", state = "Delhi / UP / Haryana", isServiceable = true),
            ServiceableCity(id = "city_2", name = "Bengaluru", state = "Karnataka", isServiceable = true),
            ServiceableCity(id = "city_3", name = "Mumbai", state = "Maharashtra", isServiceable = true),
            ServiceableCity(id = "city_4", name = "Hyderabad", state = "Telangana", isServiceable = true),
            ServiceableCity(id = "city_5", name = "Gulbarga", state = "Karnataka", isServiceable = true),
            ServiceableCity(id = "city_6", name = "Pune", state = "Maharashtra", isServiceable = true)
        )
        _serviceableCities.value = defaultCities

        val defaultServices = listOf(
            ServiceItem(
                id = "srv_in_1",
                title = "Split AC Foam Jet Wash & Deep Tune-Up",
                category = "AC & Appliances",
                description = "2x deeper cleaning with high-pressure water pump & anti-bacterial foam spray. Covers cooling coils, blower, and outdoor condenser.",
                price = 599.0,
                durationMinutes = 60,
                inclusions = listOf("Indoor unit foam jet spray", "Outdoor unit condenser wash", "Gas leak & cooling test", "Drain tray flush"),
                warrantyDays = 60,
                rating = 4.92f,
                reviewCount = 582,
                isActive = true,
                iconName = "ac_unit"
            ),
            ServiceItem(
                id = "srv_in_2",
                title = "RO Water Purifier Service & Filter Replacement",
                category = "Water & Plumbing",
                description = "Complete diagnostic of TDS levels, sediment filter change, activated carbon flush, and booster pump voltage test.",
                price = 449.0,
                durationMinutes = 45,
                inclusions = listOf("Water TDS before & after check", "Pre-sediment filter rinse", "Leakage seal inspection", "Free membrane inspection"),
                warrantyDays = 30,
                rating = 4.86f,
                reviewCount = 310,
                isActive = true,
                iconName = "water_drop"
            ),
            ServiceItem(
                id = "srv_in_3",
                title = "Emergency Pipe Leakage & Tap Brass Cartridge Fix",
                category = "Water & Plumbing",
                description = "Quick 30-min arrival for burst pipeline, concealed wall leak, or leaking mixer tap. Genuine brass fittings used.",
                price = 349.0,
                durationMinutes = 40,
                inclusions = listOf("Concealed leak diagnosis", "Teflon sealant & washer fix", "Angle valve test", "30-day rework guarantee"),
                warrantyDays = 30,
                rating = 4.88f,
                reviewCount = 420,
                isActive = true,
                iconName = "plumbing"
            ),
            ServiceItem(
                id = "srv_in_4",
                title = "Switchboard, MCB & Inverter Battery Electricals",
                category = "Electrical",
                description = "Safe testing of tripped MCB, burned switch replacement, inverter backup wire routing, and earthing voltage test.",
                price = 299.0,
                durationMinutes = 50,
                inclusions = listOf("Main DB board safety tripping test", "Modular switch install", "Inverter water & battery check", "Neutral wire isolation"),
                warrantyDays = 90,
                rating = 4.95f,
                reviewCount = 680,
                isActive = true,
                iconName = "bolt"
            ),
            ServiceItem(
                id = "srv_in_5",
                title = "Instant / Storage Geyser Element & Thermostat Repair",
                category = "AC & Appliances",
                description = "Heavy hard-water descaling of geyser heating element, thermostat calibration, and pressure safety valve replacement.",
                price = 499.0,
                durationMinutes = 60,
                inclusions = listOf("Heating rod descaling", "Thermostat auto-cut verification", "Safety valve check", "Tank leakage inspection"),
                warrantyDays = 60,
                rating = 4.79f,
                reviewCount = 215,
                isActive = true,
                iconName = "water_heater"
            ),
            ServiceItem(
                id = "srv_in_6",
                title = "Kitchen Chimney & Exhaust Degreasing Wash",
                category = "Deep Cleaning",
                description = "Chemical baffle filter cleaning, heavy grease removal from motor housing, and suction power airflow boost.",
                price = 799.0,
                durationMinutes = 90,
                inclusions = listOf("Baffle / mesh filter degreasing", "Blower motor wipe-down", "Duct pipe inspection", "Stainless steel polish"),
                warrantyDays = 30,
                rating = 4.92f,
                reviewCount = 430,
                isActive = true,
                iconName = "cleaning_services"
            )
        )
        _services.value = defaultServices

        _users.value = listOf(demoCustomer, demoTechnician, demoTechnician2)

        _bookings.value = listOf(
            Booking(
                id = "BK-IN-9081",
                customerId = "cust_in_101",
                customerName = "Aarav Sharma",
                customerPhone = "+91 98765 43210",
                customerAddress = "Tower 4, Flat 702, Sector 43, Noida, UP",
                serviceId = "srv_in_1",
                serviceTitle = "Split AC Foam Jet Wash & Deep Tune-Up",
                serviceCategory = "AC & Appliances",
                price = 599.0,
                extraCharges = 0.0,
                bookingDate = "Tomorrow, Oct 7",
                bookingTime = "10:30 AM - 11:30 AM",
                isEmergency = false,
                notes = "Master bedroom 1.5 ton Daikin AC cooling is low.",
                status = BookingStatus.ASSIGNED,
                technicianId = "tech_in_201",
                technicianName = "Rajesh Kumar Verma",
                technicianPhone = "+91 98234 56789",
                paymentMethod = "UPI (Google Pay)",
                createdAt = System.currentTimeMillis() - 86400000L
            )
        )

        val db = firestore ?: return
        scope.launch {
            try {
                // Sync serviceable_cities collection in Firestore
                db.collection("serviceable_cities").addSnapshotListener { snapshot, error ->
                    if (error == null && snapshot != null && !snapshot.isEmpty) {
                        val list = snapshot.documents.mapNotNull { it.toObject(ServiceableCity::class.java) }
                        if (list.isNotEmpty()) _serviceableCities.value = list
                    } else if (snapshot != null && snapshot.isEmpty) {
                        // Seed Firestore serviceable_cities collection
                        defaultCities.forEach { city ->
                            db.collection("serviceable_cities").document(city.id).set(city)
                        }
                    }
                }

                // Sync city_votes collection in Firestore
                db.collection("city_votes").addSnapshotListener { snapshot, error ->
                    if (error == null && snapshot != null && !snapshot.isEmpty) {
                        val list = snapshot.documents.mapNotNull { it.toObject(CityVote::class.java) }
                        _cityVotes.value = list
                    }
                }

                // Sync services collection
                db.collection("services").addSnapshotListener { snapshot, error ->
                    if (error == null && snapshot != null && !snapshot.isEmpty) {
                        val list = snapshot.documents.mapNotNull { it.toObject(ServiceItem::class.java) }
                        if (list.isNotEmpty()) _services.value = list
                    } else if (snapshot != null && snapshot.isEmpty) {
                        defaultServices.forEach { db.collection("services").document(it.id).set(it) }
                    }
                }

                // Sync bookings collection
                db.collection("bookings").addSnapshotListener { snapshot, error ->
                    if (error == null && snapshot != null && !snapshot.isEmpty) {
                        val list = snapshot.documents.mapNotNull { it.toObject(Booking::class.java) }
                        if (list.isNotEmpty()) _bookings.value = list
                    }
                }
            } catch (e: Exception) {
                Log.w("FixoraRepository", "Firestore real-time sync active: ${e.message}")
            }
        }
    }

    // City Serviceability Check & Voting
    fun setSelectedCity(cityName: String) {
        _selectedCity.value = cityName
        prefs.edit().putString("selected_city", cityName).apply()
    }

    fun isCityServiceable(cityName: String): Boolean {
        val trimmed = cityName.trim()
        return _serviceableCities.value.any { city ->
            city.isServiceable && (city.name.equals(trimmed, ignoreCase = true) ||
                    city.name.contains(trimmed, ignoreCase = true) ||
                    trimmed.contains(city.name, ignoreCase = true))
        }
    }

    fun voteForCity(cityName: String, userEmail: String): CityVote {
        val vote = CityVote(
            id = "vote_" + UUID.randomUUID().toString().take(6),
            cityName = cityName.trim().capitalizeWords(),
            userEmail = userEmail.ifBlank { "anonymous@fixora.in" },
            timestamp = System.currentTimeMillis()
        )
        _cityVotes.value = listOf(vote) + _cityVotes.value

        // Store to Firebase Firestore collection "votes" with city and userEmail as requested
        val voteData = hashMapOf(
            "id" to vote.id,
            "city" to vote.cityName,
            "cityName" to vote.cityName,
            "userEmail" to vote.userEmail,
            "timestamp" to vote.timestamp
        )
        firestore?.collection("votes")?.document(vote.id)?.set(voteData)
        firestore?.collection("city_votes")?.document(vote.id)?.set(voteData)
        return vote
    }

    // Auth & Role
    fun login(email: String, role: UserRole): Boolean {
        val trimmedEmail = email.trim()
        val existing = _users.value.find { it.email.equals(trimmedEmail, ignoreCase = true) }
        val userToLogin = existing ?: User(
            id = "user_" + UUID.randomUUID().toString().take(6),
            name = trimmedEmail.substringBefore("@").replace(".", " ").capitalizeWords(),
            email = trimmedEmail,
            phone = "+91 98765 00000",
            role = role,
            address = "Sector 62, Noida, UP",
            city = _selectedCity.value
        )

        _currentUser.value = userToLogin
        persistUserSession(userToLogin)

        firestore?.collection("users")?.document(userToLogin.id)?.set(userToLogin, SetOptions.merge())

        scope.launch {
            try {
                firebaseAuth?.signInWithEmailAndPassword(trimmedEmail, "fixora123")
            } catch (e: Exception) {
                try {
                    firebaseAuth?.createUserWithEmailAndPassword(trimmedEmail, "fixora123")
                } catch (ignored: Exception) {}
            }
        }
        return true
    }

    fun signUpCustomer(name: String, email: String, phone: String, address: String, city: String): User {
        val trimmedEmail = email.trim()
        val user = User(
            id = "cust_" + UUID.randomUUID().toString().take(6),
            name = name,
            email = trimmedEmail,
            phone = phone,
            address = address,
            city = city,
            role = UserRole.CUSTOMER,
            isOnline = true
        )
        _users.value = _users.value + user
        _currentUser.value = user
        persistUserSession(user)
        firestore?.collection("users")?.document(user.id)?.set(user)
        return user
    }

    fun applyAsTechnicianWithGovtId(
        name: String,
        email: String,
        phone: String,
        city: String,
        address: String,
        skills: List<String>,
        govtIdType: String,
        govtIdNumber: String,
        govtDocName: String
    ): User {
        val trimmedEmail = email.trim()
        val user = User(
            id = "tech_" + UUID.randomUUID().toString().take(6),
            name = name,
            email = trimmedEmail,
            phone = phone,
            city = city,
            address = address,
            skills = skills,
            role = UserRole.TECHNICIAN,
            isOnline = true,
            isVerified = true,
            governmentIdType = govtIdType,
            governmentIdNumber = govtIdNumber,
            governmentIdDocName = govtDocName.ifBlank { "govt_id_${govtIdType.lowercase().replace(" ", "_")}.jpg" },
            verificationStatus = "VERIFIED",
            rating = 5.0f,
            completedJobsCount = 0
        )
        _users.value = _users.value + user
        _currentUser.value = user
        persistUserSession(user)

        firestore?.collection("users")?.document(user.id)?.set(user)
        firestore?.collection("technicians")?.document(user.id)?.set(user)
        return user
    }

    fun switchUser(user: User) {
        _currentUser.value = user
        persistUserSession(user)
    }

    fun logout() {
        _currentUser.value = null
        persistUserSession(null)
        try { firebaseAuth?.signOut() } catch (ignored: Exception) {}
    }

    fun toggleTechnicianAvailability(userId: String, isOnline: Boolean) {
        _users.value = _users.value.map {
            if (it.id == userId) it.copy(isOnline = isOnline) else it
        }
        if (_currentUser.value?.id == userId) {
            val updated = _currentUser.value!!.copy(isOnline = isOnline)
            _currentUser.value = updated
            persistUserSession(updated)
        }
        firestore?.collection("users")?.document(userId)?.update("isOnline", isOnline)
    }

    // Booking Creation & Status
    fun createBooking(
        service: ServiceItem,
        date: String,
        time: String,
        isEmergency: Boolean,
        notes: String,
        address: String,
        paymentMethod: String
    ): Booking {
        val user = _currentUser.value ?: demoCustomer
        val bookingId = "BK-IN-" + (1000 + (Math.random() * 8999).toInt())
        val emergencyFee = if (isEmergency) 149.0 else 0.0
        val booking = Booking(
            id = bookingId,
            customerId = user.id,
            customerName = user.name,
            customerPhone = user.phone.ifEmpty { "+91 98765 43210" },
            customerAddress = address.ifEmpty { user.address },
            serviceId = service.id,
            serviceTitle = service.title,
            serviceCategory = service.category,
            price = service.price + emergencyFee,
            extraCharges = 0.0,
            bookingDate = date,
            bookingTime = time,
            isEmergency = isEmergency,
            notes = notes,
            status = BookingStatus.PENDING,
            technicianId = null,
            createdAt = System.currentTimeMillis(),
            paymentMethod = paymentMethod
        )

        _bookings.value = listOf(booking) + _bookings.value

        addNotification(
            userId = user.id,
            title = "Booking Confirmed ($bookingId)",
            message = "We have received your booking for ${service.title} in ${_selectedCity.value}.",
            bookingId = bookingId,
            type = "STATUS_UPDATE"
        )

        firestore?.collection("bookings")?.document(bookingId)?.set(booking)
        return booking
    }

    fun updateBookingStatus(bookingId: String, newStatus: BookingStatus, extraCharges: Double = 0.0, completionNotes: String = "") {
        _bookings.value = _bookings.value.map { b ->
            if (b.id == bookingId) {
                val updated = b.copy(
                    status = newStatus,
                    extraCharges = if (extraCharges > 0) extraCharges else b.extraCharges,
                    notes = if (completionNotes.isNotBlank()) "${b.notes}\n[Tech note: $completionNotes]".trim() else b.notes,
                    completedAt = if (newStatus == BookingStatus.COMPLETED) System.currentTimeMillis() else b.completedAt
                )
                firestore?.collection("bookings")?.document(bookingId)?.set(updated)

                val notifMsg = when (newStatus) {
                    BookingStatus.ASSIGNED -> "Technician has accepted your booking ($bookingId)."
                    BookingStatus.IN_PROGRESS -> "Technician has started work at your premises ($bookingId)."
                    BookingStatus.COMPLETED -> "Service ($bookingId) is completed! GST tax invoice sent to registered email."
                    BookingStatus.CANCELLED -> "Booking ($bookingId) has been cancelled."
                    else -> "Booking ($bookingId) updated to ${newStatus.displayName}."
                }
                addNotification(b.customerId, "Booking Status Update", notifMsg, bookingId, "STATUS_UPDATE")
                updated
            } else b
        }
    }

    fun cancelBooking(bookingId: String, reason: String) {
        _bookings.value = _bookings.value.map { b ->
            if (b.id == bookingId) {
                val updated = b.copy(status = BookingStatus.CANCELLED, cancellationReason = reason)
                firestore?.collection("bookings")?.document(bookingId)?.set(updated)
                addNotification(b.customerId, "Booking Cancelled", "Your booking $bookingId was cancelled. Refund will reflect in UPI/Bank within 24-48 hrs.", bookingId, "STATUS_UPDATE")
                updated
            } else b
        }
    }

    fun rescheduleBooking(bookingId: String, newDate: String, newTime: String) {
        _bookings.value = _bookings.value.map { b ->
            if (b.id == bookingId) {
                val updated = b.copy(bookingDate = newDate, bookingTime = newTime)
                firestore?.collection("bookings")?.document(bookingId)?.set(updated)
                addNotification(b.customerId, "Booking Rescheduled", "Your booking $bookingId is rescheduled to $newDate at $newTime.", bookingId, "STATUS_UPDATE")
                updated
            } else b
        }
    }

    fun rateAndReviewBooking(bookingId: String, rating: Float, comment: String) {
        _bookings.value = _bookings.value.map { b ->
            if (b.id == bookingId) {
                val updated = b.copy(rating = rating, reviewComment = comment)
                firestore?.collection("bookings")?.document(bookingId)?.set(updated)

                val review = ReviewItem(
                    id = "rev_in_" + UUID.randomUUID().toString().take(6),
                    bookingId = bookingId,
                    serviceId = b.serviceId,
                    serviceTitle = b.serviceTitle,
                    customerName = b.customerName,
                    technicianName = b.technicianName ?: "Technician",
                    rating = rating,
                    comment = comment,
                    date = "Today"
                )
                _reviews.value = listOf(review) + _reviews.value
                firestore?.collection("reviews")?.document(review.id)?.set(review)
                updated
            } else b
        }
    }

    fun updateUserProfile(user: User) {
        _users.value = _users.value.map { if (it.id == user.id) user else it }
        if (_currentUser.value?.id == user.id) {
            _currentUser.value = user
            persistUserSession(user)
        }
        firestore?.collection("users")?.document(user.id)?.set(user)
    }

    private fun addNotification(userId: String, title: String, message: String, bookingId: String?, type: String) {
        val notif = NotificationItem(
            id = "notif_" + UUID.randomUUID().toString().take(6),
            userId = userId,
            title = title,
            message = message,
            timestamp = System.currentTimeMillis(),
            isRead = false,
            bookingId = bookingId,
            type = type
        )
        _notifications.value = listOf(notif) + _notifications.value
        firestore?.collection("notifications")?.document(notif.id)?.set(notif)
    }

    fun markNotificationRead(notifId: String) {
        _notifications.value = _notifications.value.map { if (it.id == notifId) it.copy(isRead = true) else it }
        firestore?.collection("notifications")?.document(notifId)?.update("isRead", true)
    }

    fun markAllNotificationsRead() {
        _notifications.value = _notifications.value.map { it.copy(isRead = true) }
    }
}

private fun String.capitalizeWords(): String {
    return split(" ").joinToString(" ") { it.replaceFirstChar { c -> c.uppercase() } }
}
