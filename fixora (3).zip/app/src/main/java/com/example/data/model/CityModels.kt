package com.example.data.model

data class ServiceableCity(
    val id: String = "",
    val name: String = "",
    val state: String = "",
    val isServiceable: Boolean = true,
    val activeServicesCount: Int = 12
)

data class CityVote(
    val id: String = "",
    val cityName: String = "",
    val userEmail: String = "",
    val timestamp: Long = System.currentTimeMillis()
)
