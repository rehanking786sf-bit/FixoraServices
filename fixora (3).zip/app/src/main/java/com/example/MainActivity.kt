package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.example.ui.FixoraApp
import com.example.ui.FixoraViewModel
import com.example.ui.theme.FixoraTheme

class MainActivity : ComponentActivity() {

    private val viewModel: FixoraViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            FixoraTheme {
                FixoraApp(viewModel = viewModel)
            }
        }
    }
}
