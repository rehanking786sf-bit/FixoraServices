package com.example.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.Booking
import com.example.data.model.BookingStatus
import com.example.data.model.CityVote
import com.example.data.model.NotificationItem
import com.example.data.model.ReviewItem
import com.example.data.model.ServiceItem
import com.example.data.model.ServiceableCity
import com.example.data.model.User
import com.example.data.model.UserRole
import com.example.data.repository.FixoraRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

class FixoraViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = FixoraRepository.getInstance(application)

    val currentUser: StateFlow<User?> = repository.currentUser
    val selectedCity: StateFlow<String> = repository.selectedCity
    val serviceableCities: StateFlow<List<ServiceableCity>> = repository.serviceableCities
    val cityVotes: StateFlow<List<CityVote>> = repository.cityVotes

    val allServices: StateFlow<List<ServiceItem>> = repository.services
    val allBookings: StateFlow<List<Booking>> = repository.bookings
    val notifications: StateFlow<List<NotificationItem>> = repository.notifications
    val allReviews: StateFlow<List<ReviewItem>> = repository.reviews

    // Search and Category Filter for Services
    private val _searchQuery = MutableStateFlow("")
    val searchQuery = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow("All")
    val selectedCategory = _selectedCategory.asStateFlow()

    val filteredServices: StateFlow<List<ServiceItem>> = combine(
        allServices,
        _searchQuery,
        _selectedCategory
    ) { services, query, category ->
        services.filter { item ->
            val matchesCategory = (category == "All" || item.category.equals(category, ignoreCase = true))
            val matchesQuery = query.isBlank() ||
                    item.title.contains(query, ignoreCase = true) ||
                    item.description.contains(query, ignoreCase = true) ||
                    item.category.contains(query, ignoreCase = true)
            matchesCategory && matchesQuery
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Active screen navigation
    private val _currentScreen = MutableStateFlow("home")
    val currentScreen = _currentScreen.asStateFlow()

    private val _selectedService = MutableStateFlow<ServiceItem?>(null)
    val selectedService = _selectedService.asStateFlow()

    private val _selectedBooking = MutableStateFlow<Booking?>(null)
    val selectedBooking = _selectedBooking.asStateFlow()

    private val _showBookingDialog = MutableStateFlow(false)
    val showBookingDialog = _showBookingDialog.asStateFlow()

    private val _showRoleSwitcher = MutableStateFlow(false)
    val showRoleSwitcher = _showRoleSwitcher.asStateFlow()

    private val _showCitySelector = MutableStateFlow(false)
    val showCitySelector = _showCitySelector.asStateFlow()

    private val _showUnserviceableDialog = MutableStateFlow(false)
    val showUnserviceableDialog = _showUnserviceableDialog.asStateFlow()

    private val _unserviceableCityCandidate = MutableStateFlow("")
    val unserviceableCityCandidate = _unserviceableCityCandidate.asStateFlow()

    private val _toastMessage = MutableStateFlow<String?>(null)
    val toastMessage = _toastMessage.asStateFlow()

    fun navigateTo(screen: String) {
        _currentScreen.value = screen
    }

    fun selectService(service: ServiceItem?) {
        _selectedService.value = service
    }

    fun selectBooking(booking: Booking?) {
        _selectedBooking.value = booking
    }

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setSelectedCategory(cat: String) {
        _selectedCategory.value = cat
    }

    fun setShowBookingDialog(show: Boolean) {
        _showBookingDialog.value = show
    }

    fun setShowRoleSwitcher(show: Boolean) {
        _showRoleSwitcher.value = show
    }

    fun setShowCitySelector(show: Boolean) {
        _showCitySelector.value = show
    }

    fun dismissUnserviceableDialog() {
        _showUnserviceableDialog.value = false
    }

    fun clearToast() {
        _toastMessage.value = null
    }

    // City Selection and Serviceability
    fun selectCity(cityName: String) {
        _showCitySelector.value = false
        val isServiceable = repository.isCityServiceable(cityName)
        if (isServiceable) {
            repository.setSelectedCity(cityName)
            _toastMessage.value = "Location updated to $cityName. Viewing local Fixora pros."
        } else {
            // Unserviceable location flow (e.g. Lucknow)
            _unserviceableCityCandidate.value = cityName
            _showUnserviceableDialog.value = true
        }
    }

    fun voteForUnserviceableCity(cityName: String) {
        val userEmail = currentUser.value?.email ?: ""
        repository.voteForCity(cityName, userEmail)
        _showUnserviceableDialog.value = false
        _toastMessage.value = "Vote recorded for $cityName in Firebase! We will notify $userEmail when Fixora launches."
    }

    fun isCurrentCityServiceable(): Boolean {
        return repository.isCityServiceable(selectedCity.value)
    }

    // Role and Auth Actions (Only Customer and Technician)
    fun switchUser(user: User) {
        repository.switchUser(user)
        _showRoleSwitcher.value = false
        _toastMessage.value = "Switched to ${user.role.displayName}: ${user.name}"
        _currentScreen.value = "home"
    }

    fun switchRoleQuick(role: UserRole) {
        val targetUser = when (role) {
            UserRole.CUSTOMER -> repository.demoCustomer
            UserRole.TECHNICIAN -> repository.demoTechnician
        }
        switchUser(targetUser)
    }

    fun login(email: String, role: UserRole) {
        val trimmed = email.trim()
        val safeRole = if (role == UserRole.TECHNICIAN) UserRole.TECHNICIAN else UserRole.CUSTOMER
        repository.login(trimmed, safeRole)
        _toastMessage.value = "Namaste, ${currentUser.value?.name}!"
        _currentScreen.value = "home"
    }

    fun signUpCustomer(name: String, email: String, phone: String, address: String, city: String) {
        repository.signUpCustomer(name, email, phone, address, city)
        _toastMessage.value = "Account created! Welcome to Fixora, $name."
        _currentScreen.value = "home"
    }

    fun applyAsTechnicianWithGovtId(
        name: String,
        email: String,
        phone: String,
        city: String,
        address: String,
        skills: List<String>,
        govtIdType: String,
        govtIdNumber: String,
        govtDocName: String
    ) {
        repository.applyAsTechnicianWithGovtId(
            name = name,
            email = email,
            phone = phone,
            city = city,
            address = address,
            skills = skills,
            govtIdType = govtIdType,
            govtIdNumber = govtIdNumber,
            govtDocName = govtDocName
        )
        _toastMessage.value = "Technician account activated with verified Indian $govtIdType!"
        _currentScreen.value = "home"
    }

    fun logout() {
        repository.logout()
        _currentScreen.value = "auth"
    }

    // Customer Actions
    fun bookSelectedService(
        date: String,
        time: String,
        isEmergency: Boolean,
        notes: String,
        address: String,
        paymentMethod: String
    ) {
        val srv = _selectedService.value ?: return
        val booking = repository.createBooking(srv, date, time, isEmergency, notes, address, paymentMethod)
        _showBookingDialog.value = false
        _selectedBooking.value = booking
        _toastMessage.value = "Booking ${booking.id} confirmed! Verified expert assigned."
        _currentScreen.value = "booking_detail"
    }

    fun cancelBooking(bookingId: String, reason: String) {
        repository.cancelBooking(bookingId, reason)
        _toastMessage.value = "Booking $bookingId cancelled. Refund initiated to UPI/Bank."
    }

    fun rescheduleBooking(bookingId: String, newDate: String, newTime: String) {
        repository.rescheduleBooking(bookingId, newDate, newTime)
        _toastMessage.value = "Booking $bookingId rescheduled to $newDate at $newTime."
    }

    fun rateBooking(bookingId: String, rating: Float, comment: String) {
        repository.rateAndReviewBooking(bookingId, rating, comment)
        _toastMessage.value = "Dhanyawad! Your review has been published."
    }

    // Technician Actions
    fun acceptJob(bookingId: String) {
        repository.updateBookingStatus(bookingId, BookingStatus.ASSIGNED)
        _toastMessage.value = "Job $bookingId accepted! Customer notified."
    }

    fun rejectJob(bookingId: String, reason: String) {
        repository.updateBookingStatus(bookingId, BookingStatus.PENDING)
        _toastMessage.value = "Job $bookingId returned to dispatcher queue."
    }

    fun updateJobStatus(bookingId: String, newStatus: BookingStatus, extraCharges: Double = 0.0, notes: String = "") {
        repository.updateBookingStatus(bookingId, newStatus, extraCharges, notes)
        _toastMessage.value = "Job status updated to ${newStatus.displayName}."
    }

    fun toggleAvailability(isOnline: Boolean) {
        val user = currentUser.value ?: return
        repository.toggleTechnicianAvailability(user.id, isOnline)
        _toastMessage.value = if (isOnline) "You are now ONLINE and ready for jobs." else "You are now OFFLINE."
    }

    fun markNotificationRead(id: String) {
        repository.markNotificationRead(id)
    }

    fun markAllNotificationsRead() {
        repository.markAllNotificationsRead()
        _toastMessage.value = "All notifications marked read."
    }

    fun updateUserProfile(user: User) {
        repository.updateUserProfile(user)
        _toastMessage.value = "Profile updated."
    }
}
