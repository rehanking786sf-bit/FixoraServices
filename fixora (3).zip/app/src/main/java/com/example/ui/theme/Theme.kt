package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val AmberGoldLightColorScheme = lightColorScheme(
    primary = AmberGoldPrimary,
    onPrimary = Color.White,
    primaryContainer = AmberGoldContainer,
    onPrimaryContainer = AmberGoldDark,
    secondary = AmberGoldDark,
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFFFFBEB),
    onSecondaryContainer = AmberGoldDark,
    tertiary = AmberGoldAccent,
    background = GoldWhiteBackground,
    onBackground = GoldTextPrimary,
    surface = GoldWhiteCard,
    onSurface = GoldTextPrimary,
    surfaceVariant = Color(0xFFFBF8F1),
    onSurfaceVariant = GoldTextSecondary,
    outline = GoldBorder,
    error = FixoraRose
)

private val AmberGoldDarkColorScheme = darkColorScheme(
    primary = AmberGoldLight,
    onPrimary = Color(0xFF451A03),
    primaryContainer = AmberGoldDark,
    onPrimaryContainer = Color(0xFFFEF3C7),
    secondary = AmberGoldAccent,
    background = Color(0xFF1C1917),
    onBackground = Color(0xFFFAFAF9),
    surface = Color(0xFF292524),
    onSurface = Color(0xFFFAFAF9),
    surfaceVariant = Color(0xFF44403C),
    onSurfaceVariant = Color(0xFFD6D3D1),
    outline = Color(0xFF78716C)
)

@Composable
fun FixoraTheme(
    darkTheme: Boolean = false, // Keep elegant Amber Gold & White by default as requested
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) AmberGoldDarkColorScheme else AmberGoldLightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
