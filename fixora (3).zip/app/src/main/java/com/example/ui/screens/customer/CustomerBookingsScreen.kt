package com.example.ui.screens.customer

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Booking
import com.example.data.model.BookingStatus
import com.example.ui.components.BookingTimeline
import com.example.ui.components.StarRatingBar
import com.example.ui.components.StatusBadge
import com.example.ui.theme.*

@Composable
fun CustomerBookingsScreen(
    bookings: List<Booking>,
    onSelectBooking: (Booking) -> Unit,
    onCancelBooking: (bookingId: String, reason: String) -> Unit,
    onRescheduleBooking: (bookingId: String, newDate: String, newTime: String) -> Unit,
    onRateBooking: (bookingId: String, rating: Float, comment: String) -> Unit
) {
    var selectedTab by remember { mutableStateOf("All") }
    val tabs = listOf("All", "Upcoming", "In Progress", "Completed", "Cancelled")

    var bookingToCancel by remember { mutableStateOf<Booking?>(null) }
    var bookingToReschedule by remember { mutableStateOf<Booking?>(null) }
    var bookingToRate by remember { mutableStateOf<Booking?>(null) }

    val filteredBookings = remember(bookings, selectedTab) {
        when (selectedTab) {
            "Upcoming" -> bookings.filter { it.status == BookingStatus.PENDING || it.status == BookingStatus.ASSIGNED }
            "In Progress" -> bookings.filter { it.status == BookingStatus.IN_PROGRESS }
            "Completed" -> bookings.filter { it.status == BookingStatus.COMPLETED }
            "Cancelled" -> bookings.filter { it.status == BookingStatus.CANCELLED }
            else -> bookings
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .testTag("customer_bookings_screen")
    ) {
        // Tab Filters
        LazyRow(
            contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(tabs) { tab ->
                val isSelected = selectedTab == tab
                FilterChip(
                    selected = isSelected,
                    onClick = { selectedTab = tab },
                    label = { Text(tab) },
                    shape = RoundedCornerShape(12.dp)
                )
            }
        }

        if (filteredBookings.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Icon(
                        imageVector = Icons.Outlined.EventBusy,
                        contentDescription = null,
                        modifier = Modifier.size(64.dp),
                        tint = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "No $selectedTab Bookings Found",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "Your scheduled service requests will appear here.",
                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                    )
                }
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(filteredBookings) { booking ->
                    BookingItemCard(
                        booking = booking,
                        onClick = { onSelectBooking(booking) },
                        onCancelClick = { bookingToCancel = booking },
                        onRescheduleClick = { bookingToReschedule = booking },
                        onRateClick = { bookingToRate = booking }
                    )
                }
                item { Spacer(modifier = Modifier.height(64.dp)) }
            }
        }
    }

    // Cancellation Dialog
    bookingToCancel?.let { b ->
        CancelBookingDialog(
            booking = b,
            onDismiss = { bookingToCancel = null },
            onConfirmCancel = { reason ->
                onCancelBooking(b.id, reason)
                bookingToCancel = null
            }
        )
    }

    // Reschedule Dialog
    bookingToReschedule?.let { b ->
        RescheduleBookingDialog(
            booking = b,
            onDismiss = { bookingToReschedule = null },
            onConfirmReschedule = { date, time ->
                onRescheduleBooking(b.id, date, time)
                bookingToReschedule = null
            }
        )
    }

    // Rate & Review Dialog
    bookingToRate?.let { b ->
        RateServiceDialog(
            booking = b,
            onDismiss = { bookingToRate = null },
            onSubmitRating = { stars, comment ->
                onRateBooking(b.id, stars, comment)
                bookingToRate = null
            }
        )
    }
}

@Composable
fun BookingItemCard(
    booking: Booking,
    onClick: () -> Unit,
    onCancelClick: () -> Unit,
    onRescheduleClick: () -> Unit,
    onRateClick: () -> Unit
) {
    Card(
        onClick = onClick,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.fillMaxWidth().testTag("booking_card_${booking.id}")
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header: ID and Status
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = booking.id,
                        style = MaterialTheme.typography.labelLarge.copy(
                            fontWeight = FontWeight.Bold,
                            color = FixoraPrimary
                        )
                    )
                    if (booking.isEmergency) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(color = FixoraRose.copy(alpha = 0.15f), shape = RoundedCornerShape(6.dp)) {
                            Text(
                                text = "URGENT",
                                color = FixoraRose,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }

                StatusBadge(status = booking.status)
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Service Title
            Text(
                text = booking.serviceTitle,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )

            Spacer(modifier = Modifier.height(4.dp))

            // Date and Time
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.Event,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "${booking.bookingDate}  •  ${booking.bookingTime}",
                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            // Address
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.LocationOn,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = booking.customerAddress,
                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            // Technician (if assigned)
            booking.technicianName?.let { techName ->
                Spacer(modifier = Modifier.height(8.dp))
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Handyman,
                            contentDescription = null,
                            tint = FixoraPrimary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Assigned Tech: $techName",
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold)
                        )
                    }
                }
            }

            // Status Stepper Preview
            BookingTimeline(status = booking.status)

            // Rating display if completed & rated
            if (booking.rating != null) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(vertical = 4.dp)
                ) {
                    Text("Your Rating: ", style = MaterialTheme.typography.bodySmall)
                    StarRatingBar(rating = booking.rating, starSize = 14)
                }
                booking.reviewComment?.let {
                    Text(
                        text = "\"$it\"",
                        style = MaterialTheme.typography.bodySmall.copy(
                            fontStyle = androidx.compose.ui.text.font.FontStyle.Italic,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
            Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
            Spacer(modifier = Modifier.height(8.dp))

            // Footer Actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Total Price", style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant))
                    Text(
                        text = booking.formattedTotal,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = FixoraPrimary)
                    )
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    when (booking.status) {
                        BookingStatus.PENDING, BookingStatus.ASSIGNED -> {
                            OutlinedButton(
                                onClick = onRescheduleClick,
                                shape = RoundedCornerShape(10.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text("Reschedule", fontSize = 12.sp)
                            }

                            OutlinedButton(
                                onClick = onCancelClick,
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = FixoraRose),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text("Cancel", fontSize = 12.sp)
                            }
                        }
                        BookingStatus.COMPLETED -> {
                            if (booking.rating == null) {
                                Button(
                                    onClick = onRateClick,
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = FixoraAmber),
                                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                ) {
                                    Icon(Icons.Default.Star, contentDescription = null, modifier = Modifier.size(14.dp), tint = FixoraDark)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Rate Pro", color = FixoraDark, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                }
                            }
                        }
                        else -> {}
                    }

                    Button(
                        onClick = onClick,
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = FixoraPrimary),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text("Track", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }
    }
}

@Composable
fun CancelBookingDialog(
    booking: Booking,
    onDismiss: () -> Unit,
    onConfirmCancel: (reason: String) -> Unit
) {
    val reasons = listOf(
        "Change of schedule",
        "Found alternative technician",
        "Problem solved by myself",
        "Price too high",
        "Other"
    )
    var selectedReason by remember { mutableStateOf(reasons[0]) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Cancel Booking ${booking.id}") },
        text = {
            Column {
                Text("Are you sure you want to cancel this booking? Please select a reason:")
                Spacer(modifier = Modifier.height(12.dp))
                reasons.forEach { r ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = selectedReason == r,
                            onClick = { selectedReason = r }
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(r, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirmCancel(selectedReason) },
                colors = ButtonDefaults.buttonColors(containerColor = FixoraRose)
            ) {
                Text("Confirm Cancellation")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Keep Booking") }
        }
    )
}

@Composable
fun RescheduleBookingDialog(
    booking: Booking,
    onDismiss: () -> Unit,
    onConfirmReschedule: (date: String, time: String) -> Unit
) {
    val dates = listOf("Tomorrow, Oct 7", "Thu, Oct 8", "Fri, Oct 9", "Sat, Oct 10")
    val times = listOf("09:00 AM - 10:30 AM", "11:30 AM - 01:00 PM", "02:00 PM - 03:30 PM", "04:30 PM - 06:00 PM")

    var selectedDate by remember { mutableStateOf(dates[0]) }
    var selectedTime by remember { mutableStateOf(times[0]) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Reschedule Booking") },
        text = {
            Column {
                Text("Select a new slot for ${booking.serviceTitle}:")
                Spacer(modifier = Modifier.height(12.dp))
                Text("Date", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                dates.forEach { d ->
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = selectedDate == d, onClick = { selectedDate = d })
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(d, style = MaterialTheme.typography.bodyMedium)
                    }
                }
                Spacer(modifier = Modifier.height(8.dp))
                Text("Time", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                times.forEach { t ->
                    Row(
                        modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = selectedTime == t, onClick = { selectedTime = t })
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(t, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirmReschedule(selectedDate, selectedTime) },
                colors = ButtonDefaults.buttonColors(containerColor = FixoraPrimary)
            ) {
                Text("Confirm New Time")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Back") }
        }
    )
}

@Composable
fun RateServiceDialog(
    booking: Booking,
    onDismiss: () -> Unit,
    onSubmitRating: (stars: Float, comment: String) -> Unit
) {
    var rating by remember { mutableStateOf(5.0f) }
    var comment by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Rate Service & Technician") },
        text = {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("How was your experience with ${booking.technicianName ?: "your technician"}?")
                Spacer(modifier = Modifier.height(16.dp))
                StarRatingBar(
                    rating = rating,
                    onRatingChanged = { rating = it },
                    starSize = 32
                )
                Spacer(modifier = Modifier.height(16.dp))
                OutlinedTextField(
                    value = comment,
                    onValueChange = { comment = it },
                    label = { Text("Share your feedback") },
                    placeholder = { Text("Prompt arrival, great craftsmanship, clean workspace...") },
                    modifier = Modifier.fillMaxWidth(),
                    minLines = 3,
                    shape = RoundedCornerShape(12.dp)
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSubmitRating(rating, comment) },
                colors = ButtonDefaults.buttonColors(containerColor = FixoraPrimary)
            ) {
                Text("Submit Review")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Later") }
        }
    )
}
