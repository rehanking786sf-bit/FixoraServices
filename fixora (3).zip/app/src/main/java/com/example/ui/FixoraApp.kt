package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.UserRole
import com.example.ui.components.CitySelectorDialog
import com.example.ui.components.FixoraTopBar
import com.example.ui.components.RoleSwitcherModal
import com.example.ui.components.UnserviceableCityVoteDialog
import com.example.ui.screens.auth.AuthScreen
import com.example.ui.screens.customer.*
import com.example.ui.screens.technician.TechnicianDashboardScreen
import com.example.ui.screens.technician.TechnicianEarningsScreen

sealed class NavItem(val route: String, val label: String, val icon: ImageVector) {
    // Customer Nav Items
    object CustomerHome : NavItem("home", "Services", Icons.Default.Handyman)
    object CustomerBookings : NavItem("customer_bookings", "Bookings", Icons.Default.CalendarMonth)
    object CustomerNotifs : NavItem("notifications", "Alerts", Icons.Default.Notifications)
    object CustomerProfile : NavItem("profile", "Profile", Icons.Default.Person)

    // Technician Nav Items
    object TechJobs : NavItem("home", "Jobs", Icons.Default.Work)
    object TechEarnings : NavItem("tech_earnings", "Earnings", Icons.Default.Payments)
    object TechNotifs : NavItem("notifications", "Alerts", Icons.Default.Notifications)
    object TechProfile : NavItem("profile", "Profile", Icons.Default.Person)
}

@Composable
fun FixoraApp(viewModel: FixoraViewModel) {
    val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val selectedCity by viewModel.selectedCity.collectAsStateWithLifecycle()
    val serviceableCities by viewModel.serviceableCities.collectAsStateWithLifecycle()

    val filteredServices by viewModel.filteredServices.collectAsStateWithLifecycle()
    val allBookings by viewModel.allBookings.collectAsStateWithLifecycle()
    val notifications by viewModel.notifications.collectAsStateWithLifecycle()

    val searchQuery by viewModel.searchQuery.collectAsStateWithLifecycle()
    val selectedCategory by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val selectedService by viewModel.selectedService.collectAsStateWithLifecycle()
    val selectedBooking by viewModel.selectedBooking.collectAsStateWithLifecycle()

    val showBookingDialog by viewModel.showBookingDialog.collectAsStateWithLifecycle()
    val showRoleSwitcher by viewModel.showRoleSwitcher.collectAsStateWithLifecycle()
    val showCitySelector by viewModel.showCitySelector.collectAsStateWithLifecycle()
    val showUnserviceableDialog by viewModel.showUnserviceableDialog.collectAsStateWithLifecycle()
    val unserviceableCityCandidate by viewModel.unserviceableCityCandidate.collectAsStateWithLifecycle()

    val toastMessage by viewModel.toastMessage.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(toastMessage) {
        toastMessage?.let { msg ->
            snackbarHostState.showSnackbar(msg)
            viewModel.clearToast()
        }
    }

    // If no user is logged in, show AuthScreen
    if (currentUser == null || currentScreen == "auth") {
        AuthScreen(
            onLogin = { email, role -> viewModel.login(email, role) },
            onSignUpCustomer = { name, email, phone, addr, city -> viewModel.signUpCustomer(name, email, phone, addr, city) },
            onApplyTechnician = { name, email, phone, city, addr, skills, idType, idNum, docName ->
                viewModel.applyAsTechnicianWithGovtId(name, email, phone, city, addr, skills, idType, idNum, docName)
            },
            onQuickDemoLogin = { role -> viewModel.switchRoleQuick(role) }
        )
        return
    }

    val user = currentUser!!
    val unreadNotifs = notifications.count { !it.isRead && it.userId == user.id }

    // Sub-screens back navigation
    val isSubScreen = currentScreen in listOf("service_detail", "booking_detail")
    BackHandler(enabled = isSubScreen) {
        if (currentScreen == "booking_detail") {
            viewModel.navigateTo("customer_bookings")
        } else {
            viewModel.navigateTo("home")
        }
    }

    val navItems = when (user.role) {
        UserRole.CUSTOMER -> listOf(NavItem.CustomerHome, NavItem.CustomerBookings, NavItem.CustomerNotifs, NavItem.CustomerProfile)
        UserRole.TECHNICIAN -> listOf(NavItem.TechJobs, NavItem.TechEarnings, NavItem.TechNotifs, NavItem.TechProfile)
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            FixoraTopBar(
                title = when (currentScreen) {
                    "home" -> when (user.role) {
                        UserRole.CUSTOMER -> "Fixora Home Services"
                        UserRole.TECHNICIAN -> "Technician Workdesk"
                    }
                    "customer_bookings" -> "My Service Bookings"
                    "service_detail" -> selectedService?.title ?: "Service Details"
                    "booking_detail" -> "Live Progress Tracking"
                    "tech_earnings" -> "Earnings & Payouts"
                    "notifications" -> "Platform Notifications"
                    "profile" -> "My Profile & Preferences"
                    else -> "Fixora"
                },
                currentUser = user,
                selectedCity = selectedCity,
                unreadNotifCount = unreadNotifs,
                onRoleClick = { viewModel.setShowRoleSwitcher(true) },
                onCityClick = { viewModel.setShowCitySelector(true) },
                onNotificationClick = { viewModel.navigateTo("notifications") },
                showBackButton = isSubScreen,
                onBackClick = {
                    if (currentScreen == "booking_detail") {
                        viewModel.navigateTo("customer_bookings")
                    } else {
                        viewModel.navigateTo("home")
                    }
                }
            )
        },
        bottomBar = {
            if (!isSubScreen) {
                NavigationBar {
                    navItems.forEach { item ->
                        val selected = currentScreen == item.route
                        NavigationBarItem(
                            selected = selected,
                            onClick = { viewModel.navigateTo(item.route) },
                            icon = { Icon(item.icon, contentDescription = item.label) },
                            label = { Text(item.label) },
                            modifier = Modifier.testTag("nav_item_${item.route}")
                        )
                    }
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentScreen) {
                // Customer Views
                "home" -> {
                    when (user.role) {
                        UserRole.CUSTOMER -> {
                            val myActiveBookings = allBookings.filter { it.customerId == user.id }
                            CustomerHomeScreen(
                                services = filteredServices,
                                activeBookings = myActiveBookings,
                                searchQuery = searchQuery,
                                selectedCategory = selectedCategory,
                                onSearchChange = { viewModel.setSearchQuery(it) },
                                onCategorySelect = { viewModel.setSelectedCategory(it) },
                                onServiceClick = { srv ->
                                    viewModel.selectService(srv)
                                    viewModel.navigateTo("service_detail")
                                },
                                onTrackBookingClick = { b ->
                                    viewModel.selectBooking(b)
                                    viewModel.navigateTo("booking_detail")
                                },
                                onBookNowClick = { srv ->
                                    viewModel.selectService(srv)
                                    viewModel.setShowBookingDialog(true)
                                }
                            )
                        }
                        UserRole.TECHNICIAN -> {
                            TechnicianDashboardScreen(
                                currentTech = user,
                                assignedBookings = allBookings,
                                onToggleAvailability = { viewModel.toggleAvailability(it) },
                                onAcceptJob = { viewModel.acceptJob(it) },
                                onRejectJob = { id, r -> viewModel.rejectJob(id, r) },
                                onUpdateStatus = { id, s, extra, notes -> viewModel.updateJobStatus(id, s, extra, notes) }
                            )
                        }
                    }
                }

                "service_detail" -> {
                    selectedService?.let { srv ->
                        CustomerServiceDetailScreen(
                            service = srv,
                            onBackClick = { viewModel.navigateTo("home") },
                            onBookClick = { viewModel.setShowBookingDialog(true) }
                        )
                    }
                }

                "booking_detail" -> {
                    selectedBooking?.let { b ->
                        val latestBooking = allBookings.find { it.id == b.id } ?: b
                        CustomerTrackingScreen(
                            booking = latestBooking,
                            onBackClick = { viewModel.navigateTo("customer_bookings") }
                        )
                    }
                }

                "customer_bookings" -> {
                    val myBookings = allBookings.filter { it.customerId == user.id }
                    CustomerBookingsScreen(
                        bookings = myBookings,
                        onSelectBooking = { b ->
                            viewModel.selectBooking(b)
                            viewModel.navigateTo("booking_detail")
                        },
                        onCancelBooking = { id, r -> viewModel.cancelBooking(id, r) },
                        onRescheduleBooking = { id, d, t -> viewModel.rescheduleBooking(id, d, t) },
                        onRateBooking = { id, stars, c -> viewModel.rateBooking(id, stars, c) }
                    )
                }

                "notifications" -> {
                    val userNotifs = notifications.filter { it.userId == user.id }
                    CustomerNotificationsScreen(
                        notifications = userNotifs,
                        onNotificationClick = { notif ->
                            viewModel.markNotificationRead(notif.id)
                            notif.bookingId?.let { bId ->
                                val b = allBookings.find { it.id == bId }
                                if (b != null) {
                                    viewModel.selectBooking(b)
                                    viewModel.navigateTo("booking_detail")
                                }
                            }
                        },
                        onMarkAllRead = { viewModel.markAllNotificationsRead() }
                    )
                }

                "profile" -> {
                    CustomerProfileScreen(
                        currentUser = user,
                        onUpdateProfile = { viewModel.updateUserProfile(it) },
                        onOpenRoleSwitcher = { viewModel.setShowRoleSwitcher(true) },
                        onLogout = { viewModel.logout() }
                    )
                }

                // Technician Views
                "tech_earnings" -> {
                    TechnicianEarningsScreen(
                        currentTech = user,
                        allBookings = allBookings
                    )
                }
            }
        }
    }

    // Customer Booking Dialog
    if (showBookingDialog && selectedService != null) {
        CustomerBookingDialog(
            service = selectedService!!,
            currentUser = user,
            onDismiss = { viewModel.setShowBookingDialog(false) },
            onConfirmBooking = { date, time, isEmergency, notes, address, payment ->
                viewModel.bookSelectedService(date, time, isEmergency, notes, address, payment)
            }
        )
    }

    // Role Switcher Modal (Customer and Technician only)
    if (showRoleSwitcher) {
        RoleSwitcherModal(
            currentUser = user,
            onSelectCustomer = {
                viewModel.switchRoleQuick(UserRole.CUSTOMER)
                viewModel.setShowRoleSwitcher(false)
            },
            onSelectTechnician = {
                viewModel.switchRoleQuick(UserRole.TECHNICIAN)
                viewModel.setShowRoleSwitcher(false)
            },
            onDismiss = { viewModel.setShowRoleSwitcher(false) }
        )
    }

    // City Selector Dialog
    if (showCitySelector) {
        CitySelectorDialog(
            currentCity = selectedCity,
            serviceableCities = serviceableCities,
            onSelectCity = { city -> viewModel.selectCity(city) },
            onDismiss = { viewModel.setShowCitySelector(false) }
        )
    }

    // Unserviceable City Voting Dialog (e.g. Lucknow)
    if (showUnserviceableDialog) {
        UnserviceableCityVoteDialog(
            cityName = unserviceableCityCandidate,
            onVoteNow = { city -> viewModel.voteForUnserviceableCity(city) },
            onDismiss = { viewModel.dismissUnserviceableDialog() }
        )
    }
}
