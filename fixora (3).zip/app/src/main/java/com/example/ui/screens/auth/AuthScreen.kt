package com.example.ui.screens.auth

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.model.UserRole
import com.example.data.repository.FixoraRepository
import com.example.ui.theme.*

@Composable
fun AuthScreen(
    onLogin: (email: String, role: UserRole) -> Unit,
    onSignUpCustomer: (name: String, email: String, phone: String, address: String, city: String) -> Unit,
    onApplyTechnician: (
        name: String,
        email: String,
        phone: String,
        city: String,
        address: String,
        skills: List<String>,
        govtIdType: String,
        govtIdNumber: String,
        govtDocName: String
    ) -> Unit,
    onQuickDemoLogin: (UserRole) -> Unit
) {
    var isSignUp by remember { mutableStateOf(false) }
    var signUpType by remember { mutableStateOf("CUSTOMER") } // "CUSTOMER" or "TECHNICIAN"

    var email by remember { mutableStateOf("aarav.sharma@fixora.in") }
    var password by remember { mutableStateOf("password123") }
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("+91 ") }
    var address by remember { mutableStateOf("") }
    var city by remember { mutableStateOf("Delhi NCR") }

    // Technician Govt ID fields
    val indianGovtIdTypes = listOf("Aadhaar Card", "PAN Card", "Driving Licence", "Voter ID")
    var selectedGovtIdType by remember { mutableStateOf(indianGovtIdTypes[0]) }
    var govtIdNumber by remember { mutableStateOf("") }
    var uploadedDocName by remember { mutableStateOf("") }
    val availableSkills = listOf("Split AC Foam Wash", "RO Purifier Repair", "Plumbing & Leakages", "MCB & Electricals", "Geyser Repair", "Chimney Cleaning")
    val selectedSkills = remember { mutableStateListOf<String>() }

    val indianCities = listOf("Delhi NCR", "Mumbai", "Bengaluru", "Hyderabad", "Pune", "Chennai")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .verticalScroll(rememberScrollState())
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        // Fixora Logo
        Box(
            modifier = Modifier
                .size(70.dp)
                .clip(RoundedCornerShape(18.dp))
                .background(FixoraDark),
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.ic_fixora_logo),
                contentDescription = "Fixora Logo",
                modifier = Modifier.size(52.dp)
            )
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = "FIXORA",
            style = MaterialTheme.typography.headlineMedium.copy(
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 2.sp
            )
        )
        Text(
            text = "Bharat's Trusted Home & Appliance Experts",
            style = MaterialTheme.typography.bodySmall.copy(
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                fontWeight = FontWeight.Medium
            )
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Sole Admin Notice & Quick 1-Tap Demo Switcher
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.VerifiedUser, contentDescription = null, tint = AmberGoldDark, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "1-Tap Instant Demo Access",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "Explore Fixora either as a Customer or Verified Technician Partner.",
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { onQuickDemoLogin(UserRole.CUSTOMER) },
                        modifier = Modifier.weight(1f).testTag("demo_customer_btn"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = AmberGoldPrimary),
                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                    ) {
                        Text("Customer\n(Aarav)", fontSize = 12.sp, fontWeight = FontWeight.Bold, maxLines = 2)
                    }

                    Button(
                        onClick = { onQuickDemoLogin(UserRole.TECHNICIAN) },
                        modifier = Modifier.weight(1f).testTag("demo_technician_btn"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = AmberGoldDark),
                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                    ) {
                        Text("Technician Partner\n(Rajesh - Verified)", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color.White, maxLines = 2)
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Form Card
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                // Sign In / Register Tabs
                TabRow(
                    selectedTabIndex = if (isSignUp) 1 else 0,
                    containerColor = MaterialTheme.colorScheme.surface
                ) {
                    Tab(
                        selected = !isSignUp,
                        onClick = { isSignUp = false },
                        text = { Text("Sign In", fontWeight = FontWeight.Bold) }
                    )
                    Tab(
                        selected = isSignUp,
                        onClick = { isSignUp = true },
                        text = { Text("Register", fontWeight = FontWeight.Bold) }
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                if (isSignUp) {
                    // Registration Mode Selector: Customer vs Technician Partner
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FilterChip(
                            selected = signUpType == "CUSTOMER",
                            onClick = { signUpType = "CUSTOMER" },
                            label = { Text("Book Services (Customer)") },
                            modifier = Modifier.weight(1f)
                        )
                        FilterChip(
                            selected = signUpType == "TECHNICIAN",
                            onClick = { signUpType = "TECHNICIAN" },
                            label = { Text("Join as Partner (Technician)") },
                            modifier = Modifier.weight(1f)
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it },
                        label = { Text("Full Name (as per Govt ID)") },
                        leadingIcon = { Icon(Icons.Default.Person, contentDescription = null) },
                        modifier = Modifier.fillMaxWidth().testTag("auth_name_field"),
                        shape = RoundedCornerShape(12.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = phone,
                        onValueChange = { phone = it },
                        label = { Text("Indian Mobile (+91)") },
                        leadingIcon = { Icon(Icons.Default.Phone, contentDescription = null) },
                        modifier = Modifier.fillMaxWidth().testTag("auth_phone_field"),
                        shape = RoundedCornerShape(12.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = address,
                        onValueChange = { address = it },
                        label = { Text(if (signUpType == "CUSTOMER") "Home / Flat Address" else "Operational Base Address") },
                        leadingIcon = { Icon(Icons.Default.LocationOn, contentDescription = null) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    // City Selector
                    Text("Select Operating City", style = MaterialTheme.typography.labelSmall)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        indianCities.take(3).forEach { c ->
                            FilterChip(
                                selected = city == c,
                                onClick = { city = c },
                                label = { Text(c, fontSize = 11.sp) }
                            )
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        indianCities.drop(3).forEach { c ->
                            FilterChip(
                                selected = city == c,
                                onClick = { city = c },
                                label = { Text(c, fontSize = 11.sp) }
                            )
                        }
                    }

                    // Mandatory Government of India ID Section for Technician Partner
                    if (signUpType == "TECHNICIAN") {
                        Spacer(modifier = Modifier.height(14.dp))
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Badge, contentDescription = null, tint = FixoraAmber)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "Government of India ID Verification",
                                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                    )
                                }
                                Text(
                                    text = "Mandatory for technician background check & onboarding approval in India.",
                                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                )

                                Spacer(modifier = Modifier.height(10.dp))

                                // Select ID Type
                                Text("Select ID Document", style = MaterialTheme.typography.labelSmall)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    indianGovtIdTypes.forEach { idType ->
                                        FilterChip(
                                            selected = selectedGovtIdType == idType,
                                            onClick = { selectedGovtIdType = idType },
                                            label = { Text(idType, fontSize = 10.sp) }
                                        )
                                    }
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                OutlinedTextField(
                                    value = govtIdNumber,
                                    onValueChange = { govtIdNumber = it },
                                    label = { Text("$selectedGovtIdType Number") },
                                    placeholder = {
                                        Text(if (selectedGovtIdType == "Aadhaar Card") "e.g. 5421 8901 2345" else if (selectedGovtIdType == "PAN Card") "e.g. ABCDE1234F" else "Document ID No.")
                                    },
                                    modifier = Modifier.fillMaxWidth().testTag("tech_govt_id_input"),
                                    shape = RoundedCornerShape(10.dp)
                                )

                                Spacer(modifier = Modifier.height(10.dp))

                                // Document Upload simulation action
                                Surface(
                                    onClick = {
                                        uploadedDocName = "${selectedGovtIdType.lowercase().replace(" ", "_")}_proof_scan.jpg"
                                    },
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (uploadedDocName.isNotEmpty()) FixoraEmerald.copy(alpha = 0.12f) else MaterialTheme.colorScheme.surface,
                                    border = androidx.compose.foundation.BorderStroke(
                                        1.dp,
                                        if (uploadedDocName.isNotEmpty()) FixoraEmerald else FixoraPrimary
                                    ),
                                    modifier = Modifier.fillMaxWidth().testTag("upload_govt_id_button")
                                ) {
                                    Row(
                                        modifier = Modifier.padding(12.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = if (uploadedDocName.isNotEmpty()) Icons.Default.CheckCircle else Icons.Default.CloudUpload,
                                            contentDescription = null,
                                            tint = if (uploadedDocName.isNotEmpty()) FixoraEmerald else FixoraPrimary
                                        )
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column {
                                            Text(
                                                text = if (uploadedDocName.isNotEmpty()) "Uploaded: $uploadedDocName" else "Upload $selectedGovtIdType (Front & Back)",
                                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold)
                                            )
                                            Text(
                                                text = if (uploadedDocName.isNotEmpty()) "Govt of India digital proof ready for verification" else "Tap to attach Aadhaar / PAN scan",
                                                style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                }

                // Email
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Email Address") },
                    leadingIcon = { Icon(Icons.Default.Email, contentDescription = null) },
                    modifier = Modifier.fillMaxWidth().testTag("auth_email_field"),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Password
                OutlinedTextField(
                    value = password,
                    onValueChange = { password = it },
                    label = { Text("Password") },
                    leadingIcon = { Icon(Icons.Default.Lock, contentDescription = null) },
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth().testTag("auth_password_field"),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(18.dp))

                // Submit Button
                Button(
                    onClick = {
                        if (isSignUp) {
                            if (signUpType == "TECHNICIAN") {
                                onApplyTechnician(
                                    name.ifBlank { "Partner Technician" },
                                    email,
                                    phone,
                                    city,
                                    address,
                                    listOf("Split AC Service", "Plumbing", "Electricals"),
                                    selectedGovtIdType,
                                    govtIdNumber.ifBlank { "XXXX-XXXX-9988" },
                                    uploadedDocName.ifBlank { "${selectedGovtIdType.lowercase().replace(" ", "_")}_doc.jpg" }
                                )
                            } else {
                                onSignUpCustomer(name.ifBlank { "Aarav Sharma" }, email, phone, address, city)
                            }
                        } else {
                            val role = if (email.trim().contains("tech", ignoreCase = true)) UserRole.TECHNICIAN else UserRole.CUSTOMER
                            onLogin(email, role)
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("auth_submit_btn"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = FixoraPrimary)
                ) {
                    Text(
                        text = if (isSignUp) {
                            if (signUpType == "TECHNICIAN") "Submit Partner Application" else "Register Customer Account"
                        } else "Sign In to Fixora",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Google Sign In (Firebase Auth)
                OutlinedButton(
                    onClick = {
                        onLogin("aarav.sharma@fixora.in", UserRole.CUSTOMER)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("google_signin_btn"),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.AccountCircle,
                        contentDescription = "Google Sign In",
                        tint = FixoraPrimary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Continue with Google (Firebase Auth)")
                }
            }
        }

        Spacer(modifier = Modifier.height(30.dp))
    }
}
