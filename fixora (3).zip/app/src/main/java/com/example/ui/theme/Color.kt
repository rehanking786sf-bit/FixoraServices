package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Amber Gold & White Theme Palette
val AmberGoldPrimary = Color(0xFFD97706)        // Rich Amber Gold
val AmberGoldDark = Color(0xFFB45309)           // Deep Gold
val AmberGoldLight = Color(0xFFF59E0B)          // Vibrant Warm Gold
val AmberGoldContainer = Color(0xFFFEF3C7)      // Soft Gold Cream
val AmberGoldAccent = Color(0xFFEAB308)         // Radiant Golden Yellow

val GoldWhiteBackground = Color(0xFFFFFFFF)     // Pure White
val GoldWhiteSurface = Color(0xFFFCFBF9)        // Pristine Warm White
val GoldWhiteCard = Color(0xFFFFFFFF)           // Crisp White
val GoldBorder = Color(0xFFFDE68A)              // Subtle Gold Border

val GoldTextPrimary = Color(0xFF1C1917)         // Deep Stone
val GoldTextSecondary = Color(0xFF78716C)       // Muted Stone
val GoldTextGold = Color(0xFFB45309)            // Deep Amber Gold Text

val FixoraEmerald = Color(0xFF10B981)           // Success
val FixoraRose = Color(0xFFEF4444)              // Danger / Cancel
val FixoraDark = Color(0xFF1C1917)              // Dark Charcoal

// Amber Gold & White system mappings
val FixoraPrimary = AmberGoldPrimary
val FixoraPrimaryLight = AmberGoldLight
val FixoraAmber = AmberGoldLight
val FixoraCyan = AmberGoldDark
val FixoraPurple = AmberGoldDark
val FixoraBlue = AmberGoldDark
val FixoraSurfaceLight = GoldWhiteBackground
val FixoraSurfaceDark = Color(0xFF292524)
val FixoraBorder = GoldBorder
val FixoraTextPrimary = GoldTextPrimary
val FixoraTextSecondary = GoldTextSecondary
