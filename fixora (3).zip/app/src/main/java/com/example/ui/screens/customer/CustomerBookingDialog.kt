package com.example.ui.screens.customer

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ServiceItem
import com.example.data.model.User
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomerBookingDialog(
    service: ServiceItem,
    currentUser: User?,
    onDismiss: () -> Unit,
    onConfirmBooking: (
        date: String,
        time: String,
        isEmergency: Boolean,
        notes: String,
        address: String,
        paymentMethod: String
    ) -> Unit
) {
    val dates = listOf("Today, Oct 6", "Tomorrow, Oct 7", "Thu, Oct 8", "Fri, Oct 9")
    val times = listOf("09:30 AM - 11:00 AM", "11:30 AM - 01:00 PM", "02:30 PM - 04:00 PM", "04:30 PM - 06:00 PM")
    val paymentMethods = listOf("UPI (Google Pay / PhonePe)", "Paytm UPI / NetBanking", "Cash on Service After Work")

    var selectedDate by remember { mutableStateOf(dates[1]) }
    var selectedTime by remember { mutableStateOf(times[0]) }
    var address by remember { mutableStateOf(currentUser?.address ?: "Flat 402, Sector 43, Noida, UP") }
    var notes by remember { mutableStateOf("") }
    var isEmergency by remember { mutableStateOf(false) }
    var selectedPayment by remember { mutableStateOf(paymentMethods[0]) }

    val basePrice = service.price
    val emergencyFee = if (isEmergency) 149.0 else 0.0 // ₹149 in Indian currency
    val total = basePrice + emergencyFee

    AlertDialog(
        onDismissRequest = onDismiss,
        modifier = Modifier.testTag("customer_booking_dialog")
    ) {
        Surface(
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier
                .fillMaxWidth()
                .wrapContentHeight()
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Schedule Booking",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Text(
                    text = service.title,
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = FixoraPrimary,
                        fontWeight = FontWeight.SemiBold
                    )
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Date Selection
                Text(
                    text = "Select Service Date",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                )
                Spacer(modifier = Modifier.height(6.dp))
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    dates.chunked(2).forEach { rowDates ->
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            rowDates.forEach { d ->
                                val isSelected = selectedDate == d
                                Surface(
                                    onClick = { selectedDate = d },
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                                    border = if (isSelected) androidx.compose.foundation.BorderStroke(1.5.dp, FixoraPrimary) else null,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Text(
                                        text = d,
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                            color = if (isSelected) FixoraPrimary else MaterialTheme.colorScheme.onSurface
                                        ),
                                        modifier = Modifier.padding(vertical = 10.dp, horizontal = 8.dp)
                                    )
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Time Slot Selection
                Text(
                    text = "Select Slot Window",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                )
                Spacer(modifier = Modifier.height(6.dp))
                times.forEach { t ->
                    val isSelected = selectedTime == t
                    Surface(
                        onClick = { selectedTime = t },
                        shape = RoundedCornerShape(10.dp),
                        color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                        border = if (isSelected) androidx.compose.foundation.BorderStroke(1.5.dp, FixoraPrimary) else null,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (isSelected) Icons.Default.RadioButtonChecked else Icons.Default.RadioButtonUnchecked,
                                contentDescription = null,
                                tint = if (isSelected) FixoraPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = t,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                    color = if (isSelected) FixoraPrimary else MaterialTheme.colorScheme.onSurface
                                )
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Urgent Priority Toggle
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (isEmergency) FixoraRose.copy(alpha = 0.1f) else MaterialTheme.colorScheme.surfaceVariant
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Bolt, contentDescription = null, tint = FixoraRose, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "Urgent 45-Min Arrival (+ ₹149)",
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                                )
                            }
                            Text(
                                text = "Emergency technician dispatched within 45 mins",
                                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                            )
                        }
                        Switch(
                            checked = isEmergency,
                            onCheckedChange = { isEmergency = it }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Service Address Input
                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text("Service Address (Flat/Sector/City)") },
                    leadingIcon = { Icon(Icons.Default.LocationOn, contentDescription = null) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("booking_address_input"),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Problem Notes
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Specific Instructions / Issue") },
                    placeholder = { Text("e.g. 1.5 Ton Inverter AC, bring step ladder") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    minLines = 2
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Payment Method in India
                Text("Select Payment Option", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                Spacer(modifier = Modifier.height(6.dp))
                paymentMethods.forEach { method ->
                    val isSelected = selectedPayment == method
                    Surface(
                        onClick = { selectedPayment = method },
                        shape = RoundedCornerShape(10.dp),
                        color = if (isSelected) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant,
                        border = if (isSelected) androidx.compose.foundation.BorderStroke(1.dp, FixoraPrimary) else null,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (method.contains("UPI")) Icons.Default.QrCodeScanner else if (method.contains("Cash")) Icons.Default.Payments else Icons.Default.CreditCard,
                                contentDescription = null,
                                tint = if (isSelected) FixoraPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = method,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Price Breakdown Card in INR
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Service Charge (Incl. GST):", style = MaterialTheme.typography.bodyMedium)
                            Text(service.formattedPrice, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold))
                        }
                        if (isEmergency) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("Urgent 45-Min Fee:", style = MaterialTheme.typography.bodyMedium.copy(color = FixoraRose))
                                Text("₹149", style = MaterialTheme.typography.bodyMedium.copy(color = FixoraRose, fontWeight = FontWeight.SemiBold))
                            }
                        }
                        Divider(modifier = Modifier.padding(vertical = 8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("Total Payable:", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                            Text("₹${total.toInt()}", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = FixoraPrimary))
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Confirm CTA
                Button(
                    onClick = {
                        onConfirmBooking(
                            selectedDate,
                            selectedTime,
                            isEmergency,
                            notes,
                            address,
                            selectedPayment
                        )
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("confirm_booking_submit_button"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = FixoraPrimary)
                ) {
                    Text("Confirm & Book Expert (₹${total.toInt()})", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
            }
        }
    }
}
