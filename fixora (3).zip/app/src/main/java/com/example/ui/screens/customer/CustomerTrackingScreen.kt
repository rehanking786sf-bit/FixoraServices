package com.example.ui.screens.customer

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Booking
import com.example.data.model.BookingStatus
import com.example.ui.components.BookingTimeline
import com.example.ui.components.StatusBadge
import com.example.ui.theme.*

@Composable
fun CustomerTrackingScreen(
    booking: Booking,
    onBackClick: () -> Unit
) {
    val context = LocalContext.current

    Scaffold(
        modifier = Modifier.testTag("booking_tracking_screen")
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Booking #${booking.id}",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        text = "Real-time Service Progress",
                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                    )
                }
                StatusBadge(status = booking.status)
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Timeline Progress Card
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Service Milestones",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    BookingTimeline(status = booking.status)
                    Spacer(modifier = Modifier.height(8.dp))
                    val statusExplanation = when (booking.status) {
                        BookingStatus.PENDING -> "Your request is broadcasted to verified technicians. You will receive a notification once assigned."
                        BookingStatus.ASSIGNED -> "${booking.technicianName ?: "Technician"} has accepted your booking and is preparing equipment."
                        BookingStatus.IN_PROGRESS -> "Technician is on-site actively conducting repair and diagnostic work."
                        BookingStatus.COMPLETED -> "Service successfully finished! Covered under Fixora satisfaction guarantee."
                        BookingStatus.CANCELLED -> "This booking has been cancelled."
                    }
                    Text(
                        text = statusExplanation,
                        style = MaterialTheme.typography.bodySmall.copy(
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            lineHeight = 18.sp
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Assigned Technician Card (if assigned)
            if (booking.technicianName != null) {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            text = "Your Assigned Professional",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(48.dp)
                                    .clip(CircleShape)
                                    .background(FixoraPrimary),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Handyman,
                                    contentDescription = null,
                                    tint = Color.White
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = booking.technicianName,
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = "Verified Fixora Partner • ⭐ 4.9",
                                    style = MaterialTheme.typography.bodySmall.copy(color = FixoraEmerald, fontWeight = FontWeight.SemiBold)
                                )
                                Text(
                                    text = booking.technicianPhone ?: "+1 (555) 876-5432",
                                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                )
                            }

                            // Call button
                            IconButton(
                                onClick = {
                                    val phone = booking.technicianPhone ?: "5558765432"
                                    val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone"))
                                    context.startActivity(intent)
                                },
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(FixoraPrimary)
                            ) {
                                Icon(Icons.Default.Phone, contentDescription = "Call Tech", tint = Color.White)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))
            }

            // Booking Details Card
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "Booking Details",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    DetailRow(label = "Service", value = booking.serviceTitle)
                    DetailRow(label = "Category", value = booking.serviceCategory)
                    DetailRow(label = "Scheduled Date", value = booking.bookingDate)
                    DetailRow(label = "Time Slot", value = booking.bookingTime)
                    DetailRow(label = "Address", value = booking.customerAddress)
                    DetailRow(label = "Payment", value = booking.paymentMethod)
                    if (booking.notes.isNotBlank()) {
                        DetailRow(label = "Customer Notes", value = booking.notes)
                    }
                    if (booking.cancellationReason != null) {
                        DetailRow(label = "Cancellation Reason", value = booking.cancellationReason)
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Divider()
                    Spacer(modifier = Modifier.height(8.dp))

                    DetailRow(label = "Base Service Fee (GST Incl.)", value = "₹${booking.price.toInt()}")
                    if (booking.extraCharges > 0) {
                        DetailRow(label = "Extra Parts / Add-on Charges", value = "₹${booking.extraCharges.toInt()}")
                    }
                    DetailRow(
                        label = "Total Amount",
                        value = booking.formattedTotal,
                        isBold = true,
                        valueColor = FixoraPrimary
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Action Buttons
            Button(
                onClick = onBackClick,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Back to Bookings", color = MaterialTheme.colorScheme.onSurface)
            }
        }
    }
}

@Composable
private fun DetailRow(
    label: String,
    value: String,
    isBold: Boolean = false,
    valueColor: Color = Color.Unspecified
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall.copy(
                fontWeight = if (isBold) FontWeight.Bold else FontWeight.Medium,
                color = if (valueColor != Color.Unspecified) valueColor else MaterialTheme.colorScheme.onSurface
            )
        )
    }
}
