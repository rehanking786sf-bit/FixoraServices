package com.example.ui.screens.technician

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Booking
import com.example.data.model.BookingStatus
import com.example.data.model.User
import com.example.ui.components.StatusBadge
import com.example.ui.theme.*

@Composable
fun TechnicianDashboardScreen(
    currentTech: User,
    assignedBookings: List<Booking>,
    onToggleAvailability: (Boolean) -> Unit,
    onAcceptJob: (String) -> Unit,
    onRejectJob: (String, String) -> Unit,
    onUpdateStatus: (bookingId: String, newStatus: BookingStatus, extraCharges: Double, notes: String) -> Unit
) {
    val context = LocalContext.current
    var selectedTab by remember { mutableStateOf("Assigned") }
    val tabs = listOf("Assigned", "In Progress", "Completed")

    val myJobs = assignedBookings.filter { it.technicianId == currentTech.id }
    val pendingPool = assignedBookings.filter { it.status == BookingStatus.PENDING }

    val activeList = when (selectedTab) {
        "Assigned" -> myJobs.filter { it.status == BookingStatus.ASSIGNED } + pendingPool
        "In Progress" -> myJobs.filter { it.status == BookingStatus.IN_PROGRESS }
        "Completed" -> myJobs.filter { it.status == BookingStatus.COMPLETED }
        else -> myJobs
    }

    var jobToComplete by remember { mutableStateOf<Booking?>(null) }
    var jobToReject by remember { mutableStateOf<Booking?>(null) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("technician_dashboard_screen"),
        contentPadding = PaddingValues(bottom = 80.dp)
    ) {
        // Status & Availability Toggle Header
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(44.dp)
                                    .clip(CircleShape)
                                    .background(FixoraAmber),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Handyman, contentDescription = null, tint = Color.White)
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = currentTech.name,
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                    )
                                    if (currentTech.isVerified) {
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Icon(Icons.Default.Verified, contentDescription = "Verified", tint = FixoraEmerald, modifier = Modifier.size(16.dp))
                                    }
                                }
                                Text(
                                    text = "⭐ ${currentTech.rating} • ${currentTech.completedJobsCount} jobs completed",
                                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                )
                            }
                        }

                        // Availability Switch
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = if (currentTech.isOnline) "ONLINE" else "OFFLINE",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (currentTech.isOnline) FixoraEmerald else FixoraRose
                                )
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Switch(
                                checked = currentTech.isOnline,
                                onCheckedChange = onToggleAvailability,
                                modifier = Modifier.testTag("tech_availability_toggle")
                            )
                        }
                    }

                    // Govt ID Verification Badge
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Badge, contentDescription = null, tint = FixoraPrimary, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "Govt of India ID: ${currentTech.governmentIdType} (${currentTech.governmentIdNumber.ifBlank { "Verified" }})",
                                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold)
                                )
                            }
                            Surface(
                                color = if (currentTech.isVerified) FixoraEmerald.copy(alpha = 0.15f) else FixoraAmber.copy(alpha = 0.15f),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = currentTech.verificationStatus,
                                    color = if (currentTech.isVerified) FixoraEmerald else Color(0xFFB45309),
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                    Spacer(modifier = Modifier.height(12.dp))

                    // Metrics Strip in INR
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround
                    ) {
                        MetricItem(title = "Assigned", value = "${myJobs.count { it.status == BookingStatus.ASSIGNED }}")
                        MetricItem(title = "In Progress", value = "${myJobs.count { it.status == BookingStatus.IN_PROGRESS }}")
                        MetricItem(title = "Completed", value = "${myJobs.count { it.status == BookingStatus.COMPLETED }}")
                        val earnings = myJobs.filter { it.status == BookingStatus.COMPLETED }.sumOf { it.totalPrice }
                        MetricItem(title = "Earnings", value = "₹${earnings.toInt()}", highlight = true)
                    }
                }
            }
        }

        // Tabs
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                tabs.forEach { tab ->
                    val isSelected = selectedTab == tab
                    FilterChip(
                        selected = isSelected,
                        onClick = { selectedTab = tab },
                        label = { Text(tab) },
                        shape = RoundedCornerShape(12.dp)
                    )
                }
            }
        }

        // Job Items
        items(activeList) { booking ->
            TechnicianJobCard(
                booking = booking,
                isAssignedToMe = booking.technicianId == currentTech.id,
                onAccept = { onAcceptJob(booking.id) },
                onReject = { jobToReject = booking },
                onStartJob = {
                    onUpdateStatus(booking.id, BookingStatus.IN_PROGRESS, 0.0, "Started service diagnostic")
                },
                onCompleteJob = { jobToComplete = booking },
                onCallCustomer = {
                    val intent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${booking.customerPhone}"))
                    context.startActivity(intent)
                },
                onNavigateAddress = {
                    val gmmIntentUri = Uri.parse("geo:0,0?q=${Uri.encode(booking.customerAddress)}")
                    val mapIntent = Intent(Intent.ACTION_VIEW, gmmIntentUri)
                    context.startActivity(mapIntent)
                }
            )
        }

        if (activeList.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(48.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Outlined.CheckCircle,
                            contentDescription = null,
                            modifier = Modifier.size(56.dp),
                            tint = FixoraEmerald
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "No jobs in '$selectedTab'",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "Keep your status ONLINE to receive incoming service orders.",
                            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                        )
                    }
                }
            }
        }
    }

    // Complete Job Dialog with INR extra charges
    jobToComplete?.let { booking ->
        CompleteJobDialog(
            booking = booking,
            onDismiss = { jobToComplete = null },
            onConfirm = { extra, notes ->
                onUpdateStatus(booking.id, BookingStatus.COMPLETED, extra, notes)
                jobToComplete = null
            }
        )
    }

    // Reject Job Dialog
    jobToReject?.let { booking ->
        RejectJobDialog(
            booking = booking,
            onDismiss = { jobToReject = null },
            onConfirm = { reason ->
                onRejectJob(booking.id, reason)
                jobToReject = null
            }
        )
    }
}

@Composable
fun TechnicianJobCard(
    booking: Booking,
    isAssignedToMe: Boolean,
    onAccept: () -> Unit,
    onReject: () -> Unit,
    onStartJob: () -> Unit,
    onCompleteJob: () -> Unit,
    onCallCustomer: () -> Unit,
    onNavigateAddress: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 6.dp)
            .testTag("tech_job_card_${booking.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = booking.id,
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = FixoraPrimary)
                    )
                    if (booking.isEmergency) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(color = FixoraRose.copy(alpha = 0.15f), shape = RoundedCornerShape(6.dp)) {
                            Text(
                                text = "EMERGENCY (₹149)",
                                color = FixoraRose,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
                StatusBadge(status = booking.status)
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = booking.serviceTitle,
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )

            Spacer(modifier = Modifier.height(6.dp))

            // Customer Name & Contact
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Person, contentDescription = null, tint = FixoraPrimary, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "${booking.customerName} (${booking.customerPhone})",
                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold)
                    )
                }

                IconButton(
                    onClick = onCallCustomer,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(Icons.Default.Phone, contentDescription = "Call Customer", tint = FixoraPrimary)
                }
            }

            // Customer Address & Navigation
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.LocationOn, contentDescription = null, tint = FixoraAmber, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = booking.customerAddress,
                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant),
                    modifier = Modifier.weight(1f)
                )
                IconButton(
                    onClick = onNavigateAddress,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(Icons.Default.Directions, contentDescription = "Directions", tint = FixoraPrimary)
                }
            }

            // Scheduled slot
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Schedule, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "${booking.bookingDate}  •  ${booking.bookingTime}",
                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                )
            }

            if (booking.notes.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Notes: ${booking.notes}",
                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant),
                        modifier = Modifier.padding(8.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
            Spacer(modifier = Modifier.height(10.dp))

            // Action Buttons for Technician in INR
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Payout: ${booking.formattedTotal}",
                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = FixoraEmerald)
                )

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    when (booking.status) {
                        BookingStatus.PENDING -> {
                            Button(
                                onClick = onAccept,
                                colors = ButtonDefaults.buttonColors(containerColor = FixoraEmerald),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text("Accept Job", fontWeight = FontWeight.Bold)
                            }
                        }
                        BookingStatus.ASSIGNED -> {
                            OutlinedButton(
                                onClick = onReject,
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = FixoraRose),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text("Decline")
                            }
                            Button(
                                onClick = onStartJob,
                                colors = ButtonDefaults.buttonColors(containerColor = FixoraPrimary),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Text("Start Work", fontWeight = FontWeight.Bold)
                            }
                        }
                        BookingStatus.IN_PROGRESS -> {
                            Button(
                                onClick = onCompleteJob,
                                colors = ButtonDefaults.buttonColors(containerColor = FixoraEmerald),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Finish Job", fontWeight = FontWeight.Bold)
                            }
                        }
                        BookingStatus.COMPLETED -> {
                            Surface(color = FixoraEmerald.copy(alpha = 0.15f), shape = RoundedCornerShape(8.dp)) {
                                Text(
                                    text = "Completed & Invoiced",
                                    color = FixoraEmerald,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                        else -> {}
                    }
                }
            }
        }
    }
}

@Composable
fun CompleteJobDialog(
    booking: Booking,
    onDismiss: () -> Unit,
    onConfirm: (extraCharges: Double, notes: String) -> Unit
) {
    var extraStr by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Complete Job ${booking.id}") },
        text = {
            Column {
                Text("Confirm completion for ${booking.serviceTitle}.")
                Spacer(modifier = Modifier.height(12.dp))
                OutlinedTextField(
                    value = extraStr,
                    onValueChange = { extraStr = it },
                    label = { Text("Extra parts / brass valve / filter (₹)") },
                    placeholder = { Text("0") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Technician Service Notes") },
                    placeholder = { Text("AC cooling pressure checked, genuine capacitor installed.") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    minLines = 2
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val extra = extraStr.toDoubleOrNull() ?: 0.0
                    onConfirm(extra, notes)
                },
                colors = ButtonDefaults.buttonColors(containerColor = FixoraEmerald)
            ) {
                Text("Confirm & Bill")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
fun RejectJobDialog(
    booking: Booking,
    onDismiss: () -> Unit,
    onConfirm: (reason: String) -> Unit
) {
    val reasons = listOf("Traffic/Heavy rain in area", "Outside service territory", "Specialized tool/gas kit missing", "Overbooked today")
    var selectedReason by remember { mutableStateOf(reasons[0]) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Decline Job ${booking.id}") },
        text = {
            Column {
                Text("Return this job back to dispatcher queue. Select reason:")
                Spacer(modifier = Modifier.height(10.dp))
                reasons.forEach { r ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = selectedReason == r, onClick = { selectedReason = r })
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(r, style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onConfirm(selectedReason) },
                colors = ButtonDefaults.buttonColors(containerColor = FixoraRose)
            ) {
                Text("Decline")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}

@Composable
private fun MetricItem(title: String, value: String, highlight: Boolean = false) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = value,
            style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.ExtraBold,
                color = if (highlight) FixoraEmerald else MaterialTheme.colorScheme.onSurface
            )
        )
        Text(
            text = title,
            style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
        )
    }
}
