package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.BookingStatus
import com.example.data.model.ServiceableCity
import com.example.data.model.User
import com.example.data.model.UserRole
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FixoraTopBar(
    title: String,
    currentUser: User?,
    selectedCity: String,
    unreadNotifCount: Int,
    onRoleClick: () -> Unit,
    onCityClick: () -> Unit,
    onNotificationClick: () -> Unit,
    showBackButton: Boolean = false,
    onBackClick: () -> Unit = {}
) {
    TopAppBar(
        title = {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                // City Selector Chip
                Surface(
                    onClick = onCityClick,
                    shape = RoundedCornerShape(10.dp),
                    color = AmberGoldContainer.copy(alpha = 0.7f),
                    modifier = Modifier.padding(top = 2.dp).testTag("topbar_city_selector")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocationOn,
                            contentDescription = null,
                            tint = AmberGoldDark,
                            modifier = Modifier.size(13.dp)
                        )
                        Spacer(modifier = Modifier.width(3.dp))
                        Text(
                            text = selectedCity,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = AmberGoldDark,
                                fontSize = 11.sp
                            )
                        )
                        Spacer(modifier = Modifier.width(2.dp))
                        Icon(
                            imageVector = Icons.Default.ArrowDropDown,
                            contentDescription = null,
                            tint = AmberGoldDark,
                            modifier = Modifier.size(15.dp)
                        )
                    }
                }
            }
        },
        navigationIcon = {
            if (showBackButton) {
                IconButton(onClick = onBackClick, modifier = Modifier.testTag("topbar_back_button")) {
                    Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                }
            } else {
                IconButton(onClick = onRoleClick, modifier = Modifier.testTag("topbar_role_avatar")) {
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .clip(CircleShape)
                            .background(
                                when (currentUser?.role) {
                                    UserRole.TECHNICIAN -> AmberGoldPrimary
                                    else -> AmberGoldLight
                                }
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = (currentUser?.name?.firstOrNull() ?: 'F').toString(),
                            color = Color.White,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp
                        )
                    }
                }
            }
        },
        actions = {
            // Quick role chip (Customer vs Technician only)
            currentUser?.let { user ->
                Surface(
                    onClick = onRoleClick,
                    shape = RoundedCornerShape(16.dp),
                    color = AmberGoldContainer,
                    modifier = Modifier.padding(end = 4.dp).testTag("quick_role_switch_chip")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(
                                    when (user.role) {
                                        UserRole.TECHNICIAN -> if (user.isOnline) FixoraEmerald else FixoraRose
                                        UserRole.CUSTOMER -> AmberGoldPrimary
                                    }
                                )
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = user.role.displayName,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = AmberGoldDark
                            )
                        )
                    }
                }
            }

            // Notification Bell with badge
            IconButton(
                onClick = onNotificationClick,
                modifier = Modifier.testTag("notification_bell_button")
            ) {
                BadgedBox(
                    badge = {
                        if (unreadNotifCount > 0) {
                            Badge(containerColor = FixoraRose) {
                                Text(unreadNotifCount.toString())
                            }
                        }
                    }
                ) {
                    Icon(
                        imageVector = Icons.Outlined.Notifications,
                        contentDescription = "Notifications"
                    )
                }
            }
        },
        colors = TopAppBarDefaults.topAppBarColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    )
}

@Composable
fun StatusBadge(status: BookingStatus) {
    val (bgColor, textColor) = when (status) {
        BookingStatus.PENDING -> Pair(AmberGoldContainer, AmberGoldDark)
        BookingStatus.ASSIGNED -> Pair(AmberGoldContainer.copy(alpha = 0.7f), AmberGoldDark)
        BookingStatus.IN_PROGRESS -> Pair(AmberGoldLight.copy(alpha = 0.2f), AmberGoldDark)
        BookingStatus.COMPLETED -> Pair(FixoraEmerald.copy(alpha = 0.15f), FixoraEmerald)
        BookingStatus.CANCELLED -> Pair(FixoraRose.copy(alpha = 0.15f), FixoraRose)
    }

    Surface(
        shape = RoundedCornerShape(12.dp),
        color = bgColor
    ) {
        Text(
            text = status.displayName,
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.SemiBold,
                color = textColor
            ),
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}

@Composable
fun StarRatingBar(
    rating: Float,
    maxStars: Int = 5,
    onRatingChanged: ((Float) -> Unit)? = null,
    modifier: Modifier = Modifier,
    starSize: Int = 18
) {
    Row(modifier = modifier, verticalAlignment = Alignment.CenterVertically) {
        for (i in 1..maxStars) {
            val isSelected = i <= rating
            Icon(
                imageVector = if (isSelected) Icons.Default.Star else Icons.Default.StarBorder,
                contentDescription = "$i stars",
                tint = if (isSelected) AmberGoldPrimary else Color.LightGray,
                modifier = Modifier
                    .size(starSize.dp)
                    .then(
                        if (onRatingChanged != null) {
                            Modifier.clickable { onRatingChanged(i.toFloat()) }
                        } else Modifier
                    )
            )
        }
    }
}

@Composable
fun BookingTimeline(status: BookingStatus) {
    val steps = listOf(
        Pair(BookingStatus.PENDING, "Requested"),
        Pair(BookingStatus.ASSIGNED, "Assigned"),
        Pair(BookingStatus.IN_PROGRESS, "In Progress"),
        Pair(BookingStatus.COMPLETED, "Completed")
    )

    val currentStepIndex = when (status) {
        BookingStatus.PENDING -> 0
        BookingStatus.ASSIGNED -> 1
        BookingStatus.IN_PROGRESS -> 2
        BookingStatus.COMPLETED -> 3
        BookingStatus.CANCELLED -> -1
    }

    if (status == BookingStatus.CANCELLED) {
        Surface(
            color = FixoraRose.copy(alpha = 0.12f),
            shape = RoundedCornerShape(12.dp),
            modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp)
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Cancel, contentDescription = null, tint = FixoraRose)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "This booking was cancelled.",
                    style = MaterialTheme.typography.bodyMedium.copy(
                        color = FixoraRose,
                        fontWeight = FontWeight.SemiBold
                    )
                )
            }
        }
        return
    }

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        steps.forEachIndexed { index, pair ->
            val isPassed = index <= currentStepIndex
            val isCurrent = index == currentStepIndex

            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.weight(1f)
            ) {
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(CircleShape)
                        .background(
                            when {
                                isPassed -> AmberGoldPrimary
                                else -> MaterialTheme.colorScheme.surfaceVariant
                            }
                        )
                        .then(
                            if (isCurrent) Modifier.border(2.dp, AmberGoldDark, CircleShape)
                            else Modifier
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    if (isPassed) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                    } else {
                        Text(
                            text = "${index + 1}",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = pair.second,
                    style = MaterialTheme.typography.labelSmall.copy(
                        fontSize = 10.sp,
                        fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.Normal,
                        color = if (isPassed) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
                    ),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            if (index < steps.size - 1) {
                Box(
                    modifier = Modifier
                        .weight(0.5f)
                        .height(2.dp)
                        .background(
                            if (index < currentStepIndex) AmberGoldPrimary
                            else MaterialTheme.colorScheme.surfaceVariant
                        )
                )
            }
        }
    }
}

// Location Selector Dialog
@Composable
fun CitySelectorDialog(
    currentCity: String,
    serviceableCities: List<ServiceableCity>,
    onSelectCity: (String) -> Unit,
    onDismiss: () -> Unit
) {
    var searchInput by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Select Your City", fontWeight = FontWeight.Bold) },
        text = {
            Column {
                OutlinedTextField(
                    value = searchInput,
                    onValueChange = { searchInput = it },
                    placeholder = { Text("Search city (e.g. Gulbarga, Lucknow)") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    modifier = Modifier.fillMaxWidth().testTag("city_search_input"),
                    shape = RoundedCornerShape(12.dp)
                )

                if (searchInput.isNotBlank()) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Button(
                        onClick = { onSelectCity(searchInput.trim()) },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.buttonColors(containerColor = AmberGoldPrimary)
                    ) {
                        Text("Search & Set '$searchInput'")
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))
                Text(
                    text = "Active Serviceable Cities (Firebase):",
                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold, color = AmberGoldDark)
                )
                Spacer(modifier = Modifier.height(8.dp))

                serviceableCities.forEach { city ->
                    val isSelected = city.name.equals(currentCity, ignoreCase = true)
                    Surface(
                        onClick = { onSelectCity(city.name) },
                        shape = RoundedCornerShape(10.dp),
                        color = if (isSelected) AmberGoldContainer else MaterialTheme.colorScheme.surfaceVariant,
                        border = if (isSelected) androidx.compose.foundation.BorderStroke(1.5.dp, AmberGoldDark) else null,
                        modifier = Modifier.fillMaxWidth().padding(vertical = 3.dp).testTag("select_city_${city.name}")
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(city.name, fontWeight = FontWeight.Bold)
                                Text(city.state, style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant))
                            }
                            if (isSelected) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = AmberGoldDark)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Close") }
        }
    )
}

// Unserviceable City Notification & Vote Now Dialog
@Composable
fun UnserviceableCityVoteDialog(
    cityName: String,
    onVoteNow: (String) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        icon = {
            Icon(Icons.Default.LocationOff, contentDescription = null, tint = FixoraRose, modifier = Modifier.size(36.dp))
        },
        title = {
            Text("Fixora is not in $cityName yet", fontWeight = FontWeight.Bold)
        },
        text = {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "Sorry, this location is unserviceable currently. Vote now to bring Fixora verified technicians to $cityName!",
                    style = MaterialTheme.typography.bodyMedium,
                    lineHeight = 20.sp
                )
                Spacer(modifier = Modifier.height(10.dp))
                Surface(
                    color = AmberGoldContainer,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Your vote helps prioritize $cityName in our next city expansion phase.",
                        style = MaterialTheme.typography.bodySmall.copy(color = AmberGoldDark),
                        modifier = Modifier.padding(8.dp)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onVoteNow(cityName) },
                colors = ButtonDefaults.buttonColors(containerColor = AmberGoldPrimary),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.testTag("vote_now_button")
            ) {
                Icon(Icons.Default.HowToVote, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("Vote Now for $cityName", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Change City") }
        }
    )
}

// Role Switcher Modal (Customer and Technician ONLY)
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RoleSwitcherModal(
    currentUser: User?,
    onSelectCustomer: () -> Unit,
    onSelectTechnician: () -> Unit,
    onDismiss: () -> Unit
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp)
        ) {
            Text(
                text = "Switch Experience",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
            )
            Text(
                text = "Toggle seamlessly between Customer and Technician mode",
                style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant),
                modifier = Modifier.padding(top = 4.dp, bottom = 14.dp)
            )

            // Customer Option
            val isCustomer = currentUser?.role == UserRole.CUSTOMER
            Surface(
                onClick = onSelectCustomer,
                shape = RoundedCornerShape(12.dp),
                color = if (isCustomer) AmberGoldContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                border = if (isCustomer) borderStroke(1.5.dp, AmberGoldDark) else null,
                modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp).testTag("switch_to_customer")
            ) {
                Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier.size(44.dp).clip(CircleShape).background(AmberGoldLight),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Person, contentDescription = null, tint = Color.White)
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Customer Perspective", fontWeight = FontWeight.Bold)
                        Text("Browse services, book repairs in your city, track jobs", style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant))
                    }
                    if (isCustomer) Icon(Icons.Default.CheckCircle, contentDescription = null, tint = AmberGoldDark)
                }
            }

            // Technician Option
            val isTech = currentUser?.role == UserRole.TECHNICIAN
            Surface(
                onClick = onSelectTechnician,
                shape = RoundedCornerShape(12.dp),
                color = if (isTech) AmberGoldContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                border = if (isTech) borderStroke(1.5.dp, AmberGoldDark) else null,
                modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp).testTag("switch_to_technician")
            ) {
                Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier.size(44.dp).clip(CircleShape).background(AmberGoldPrimary),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Handyman, contentDescription = null, tint = Color.White)
                    }
                    Spacer(modifier = Modifier.width(14.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Technician Partner Mode", fontWeight = FontWeight.Bold)
                        Text("Accept dispatches, manage availability, view earnings", style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant))
                    }
                    if (isTech) Icon(Icons.Default.CheckCircle, contentDescription = null, tint = AmberGoldDark)
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

private fun borderStroke(width: androidx.compose.ui.unit.Dp, color: Color) =
    androidx.compose.foundation.BorderStroke(width, color)
