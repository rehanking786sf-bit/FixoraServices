package com.example.ui.screens.technician

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Booking
import com.example.data.model.BookingStatus
import com.example.data.model.User
import com.example.ui.components.StarRatingBar
import com.example.ui.theme.*

@Composable
fun TechnicianEarningsScreen(
    currentTech: User,
    allBookings: List<Booking>
) {
    val completedJobs = allBookings.filter {
        it.technicianId == currentTech.id && it.status == BookingStatus.COMPLETED
    }

    val totalEarnings = completedJobs.sumOf { it.totalPrice }
    val thisWeekEarnings = totalEarnings * 0.45
    val todayEarnings = if (completedJobs.isNotEmpty()) completedJobs.first().totalPrice else 0.0

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .testTag("technician_earnings_screen"),
        contentPadding = PaddingValues(16.dp, 16.dp, 16.dp, 80.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Card in INR
        item {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = FixoraDark),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "Total Partner Payout (INR)",
                        style = MaterialTheme.typography.bodyMedium.copy(color = Color(0xFF94A3B8))
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "₹${String.format("%,d", totalEarnings.toLong())}",
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.ExtraBold,
                            color = Color.White
                        )
                    )
                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text("This Week", style = MaterialTheme.typography.labelSmall.copy(color = Color(0xFF94A3B8)))
                            Text("₹${String.format("%,d", thisWeekEarnings.toLong())}", style = MaterialTheme.typography.titleMedium.copy(color = FixoraEmerald, fontWeight = FontWeight.Bold))
                        }
                        Column {
                            Text("Today", style = MaterialTheme.typography.labelSmall.copy(color = Color(0xFF94A3B8)))
                            Text("₹${String.format("%,d", todayEarnings.toLong())}", style = MaterialTheme.typography.titleMedium.copy(color = FixoraAmber, fontWeight = FontWeight.Bold))
                        }
                        Column {
                            Text("Jobs Done", style = MaterialTheme.typography.labelSmall.copy(color = Color(0xFF94A3B8)))
                            Text("${completedJobs.size}", style = MaterialTheme.typography.titleMedium.copy(color = Color.White, fontWeight = FontWeight.Bold))
                        }
                    }
                }
            }
        }

        // Performance & Govt ID Standing
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Partner Standing & Rating",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Surface(
                            color = if (currentTech.isVerified) FixoraEmerald.copy(alpha = 0.15f) else FixoraAmber.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "Govt ID: ${currentTech.verificationStatus}",
                                color = if (currentTech.isVerified) FixoraEmerald else Color(0xFFB45309),
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        StarRatingBar(rating = currentTech.rating, starSize = 20)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "${currentTech.rating} (Top Rated Expert in ${currentTech.city})",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = FixoraEmerald)
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Specialties: ${currentTech.skills.joinToString(", ")}",
                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                    )
                    Text(
                        text = "Verified Govt ID: ${currentTech.governmentIdType} (${currentTech.governmentIdNumber})",
                        style = MaterialTheme.typography.labelSmall.copy(color = FixoraPrimary, fontWeight = FontWeight.SemiBold)
                    )
                }
            }
        }

        // Completed Jobs Section Title
        item {
            Text(
                text = "Completed Payouts History (${completedJobs.size})",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
        }

        items(completedJobs) { job ->
            Card(
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = job.serviceTitle,
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = "Customer: ${job.customerName} • ${job.bookingDate}",
                            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                        )
                        if (job.rating != null) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("Customer rating: ", style = MaterialTheme.typography.labelSmall)
                                StarRatingBar(rating = job.rating, starSize = 12)
                            }
                        }
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text(
                            text = "+${job.formattedTotal}",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = FixoraEmerald
                            )
                        )
                        Surface(
                            color = FixoraEmerald.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "Credited to Bank",
                                color = FixoraEmerald,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
